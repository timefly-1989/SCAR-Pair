#!/usr/bin/env python3
"""Single-panel paired-effect plot for the post-review control evidence.

Claim: the observed nDCG advantage over these three controls is uncertain.
All 391 tasks enter each stratified paired contrast; intervals resample the 366
shared-gold-source components. This plot is descriptive and uses no selection.
"""
import json
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
from audit_panel_alignment import require_matplotlib_panel_alignment

ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / "reproduction/output/revision_statistics_report.json"
PREFIX = ROOT / "figures/revision_controls"

mpl.rcParams.update({
    "font.family": "sans-serif", "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
    "font.size": 7, "axes.labelsize": 7, "xtick.labelsize": 6.5, "ytick.labelsize": 7,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.linewidth": .65, "pdf.fonttype": 42, "svg.fonttype": "none",
    "savefig.facecolor": "white",
})


def main():
    report = json.loads(REPORT.read_text())
    lookup = {r["right"]: r for r in report["results"] if r.get("domain") == "retrieval"
              and r.get("protocol") == "stratified" and r.get("left") == "SCAR-Pair"
              and r.get("metric") == "ndcg"}
    items = [("Query-CE replay", lookup["Query-CE-replay"])]
    items.extend((f"Mismatch {i}", lookup[f"Mismatched-schema-CE-{i}"])
                 for i in range(1, 6))
    items.append(("No-insertion refit", lookup["No-insertion-refit"]))
    fig, ax = plt.subplots(figsize=(3.50, 2.45), layout="constrained")
    ax.axvline(0, color="#727b84", linewidth=.8, linestyle=(0, (2, 2)), zorder=0)
    positions = list(reversed(range(len(items))))
    for y, (name, row) in zip(positions, items):
        point = row["difference"]
        low, high = row["ci95"]
        color = "#265e82" if name != "No-insertion refit" else "#6c6c6c"
        ax.plot([low, high], [y, y], color=color, linewidth=1.5, solid_capstyle="round")
        ax.plot([low, low], [y-.075, y+.075], color=color, linewidth=.8)
        ax.plot([high, high], [y-.075, y+.075], color=color, linewidth=.8)
        ax.scatter([point], [y], s=29, facecolor="white", edgecolor=color,
                   linewidth=1.15, zorder=3)
    ax.set_yticks(positions, [x[0] for x in items])
    ax.set_xlim(-.02, .03)
    ax.set_xticks([-.02, -.01, 0, .01, .02, .03])
    ax.set_ylim(-.4, len(items) - .6)
    ax.set_xlabel(r"$\Delta$ nDCG@5 (SCAR-Pair minus control)")
    ax.tick_params(axis="y", length=0, pad=5)
    ax.tick_params(axis="x", length=2.5, width=.6)
    ax.spines["left"].set_visible(False)
    fig.canvas.draw()
    require_matplotlib_panel_alignment(
        fig, json_out=str(PREFIX) + ".alignment.json",
        overlay_svg=str(PREFIX) + ".alignment.svg", strict=True)
    fig.savefig(str(PREFIX) + ".pdf", bbox_inches="tight")
    fig.savefig(str(PREFIX) + ".svg", bbox_inches="tight")
    fig.savefig(str(PREFIX) + ".png", dpi=600, bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    main()
