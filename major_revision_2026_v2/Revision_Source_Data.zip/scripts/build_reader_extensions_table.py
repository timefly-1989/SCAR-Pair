#!/usr/bin/env python3
"""Build the supplementary constrained and multi-reader result table."""

from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "reproduction/output"
TABLE = ROOT / "tables/generated/revision_reader_extensions.tex"


def load(name):
    return json.loads((OUTPUT / name).read_text())


def escape(text):
    return text.replace("-", "--")


def main():
    groups = [
        ("Qwen2.5--1.5B", "Unconstrained", load("publication_reader_report.json")["consistent"]),
        ("Qwen2.5--1.5B", "Selected-tool arguments", load("revision_constrained_reader_report.json")["results_constrained"]),
        ("Qwen2.5--3B", "Unconstrained, 4-bit", load("revision_multireader_qwen25_3b_report.json")["results_consistent_tasks"]),
        ("Phi--3.5-mini", "Unconstrained, 4-bit", load("revision_multireader_phi35_mini_report.json")["results_consistent_tasks"]),
    ]
    wanted = ("No-memory", "Query-Fuse-strict", "SCAR-Pair", "Oracle-Gold")
    lines = [
        r"\begin{table}[tbp]",
        r"\caption{Selected-tool-constrained and multi-reader results on the same 385 gold-schema-consistent tasks. All conditions use the same ranked document IDs, five-memory limit, greedy decoding, strict parser, recursive validator, and exact-match definitions. The unconstrained reader replications use the same tool-call instruction, with token truncation following each model's tokenizer. The selected-tool control instead fixes tool identity and decodes only an argument object; the 3B and Phi readers use 4-bit MLX checkpoints.}",
        r"\label{tab:revision_reader_extensions}",
        r"\centering\scriptsize",
        r"\setlength{\tabcolsep}{3.5pt}",
        r"\begin{tabular}{lllrrrr}",
        r"\toprule",
        r"Reader & Decoding & Context & Schema & Arg-EM & Mem-call & Full-call \\",
        r"\midrule",
    ]
    for gi, (reader_name, decoding, rows) in enumerate(groups):
        lookup = {r["condition"]: r for r in rows}
        for ci, condition in enumerate(wanted):
            row = lookup[condition]
            first = reader_name if ci == 0 else ""
            second = decoding if ci == 0 else ""
            context = {"No-memory": "No memory", "Query-Fuse-strict": "Query-Fuse"}.get(condition, condition)
            lines.append(
                f"{first} & {second} & {context} & "
                f"{row['schema_validity']:.3f} & {row['memory_argument_em']:.3f} & "
                f"{row['memory_call_em']:.3f} & {row['full_call_em']:.3f} " + r"\\"
            )
        if gi != len(groups) - 1:
            lines.append(r"\addlinespace")
    lines.extend([r"\bottomrule", r"\end{tabular}", r"\end{table}"])
    TABLE.write_text("\n".join(lines) + "\n")
    print(TABLE)


if __name__ == "__main__":
    main()
