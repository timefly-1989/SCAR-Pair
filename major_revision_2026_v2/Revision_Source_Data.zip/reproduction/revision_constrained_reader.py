#!/usr/bin/env python3
"""Selected-tool-constrained reader control on frozen Qwen2.5-1.5B.

The selected tool is fixed by the interface and the reader generates only its
argument object.  A deterministic wrapper then combines that object with the
observed selected name.  Unlike the earlier post-generation name lock, the
reader is instructed before decoding that tool selection is unavailable and
all generated tokens belong to the arguments channel.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import time
from collections import Counter

import numpy as np
import torch
from tqdm import tqdm

import reader_reproduce as reader
import scar_pair_reproduce as base
from reader_parser_audit import reject_constant, unique_object


CONDITIONS = ("No-memory", "Query-Fuse-strict", "SCAR-Pair", "Oracle-Gold")
OUTPUT = base.OUTPUT / "revision_constrained_reader_predictions.jsonl"
REPORT = base.OUTPUT / "revision_constrained_reader_report.json"
CONSTRAINED_SYSTEM = (
    "The tool has already been selected and cannot be changed. Fill only the "
    "arguments for the selected tool using the current request, its schema, and "
    "any retrieved memory conversations. Return exactly one JSON object whose "
    "keys are parameters defined by the selected schema. Do not return a tool "
    "name, an arguments wrapper, Markdown, or prose. Infer missing values only "
    "when supported by the request or memory; use a schema default when one is "
    "explicitly specified."
)


def build_constrained_prompt(task, doc_indices, corpus, tokenizer):
    budget = reader.MAX_MEMORY_TOKENS
    while True:
        messages = reader.messages_for(task, doc_indices, corpus, tokenizer, budget)
        messages[0] = {"role": "system", "content": CONSTRAINED_SYSTEM}
        ids = tokenizer.apply_chat_template(
            messages, tokenize=True, add_generation_prompt=True, return_tensors=None
        )
        if len(ids) <= reader.MAX_PROMPT_TOKENS:
            return messages, ids, budget
        if not doc_indices or budget <= 32:
            raise ValueError(
                f"Base prompt exceeds {reader.MAX_PROMPT_TOKENS} tokens for {task['qa_id']}"
            )
        budget -= max(
            1,
            min(
                64,
                (len(ids) - reader.MAX_PROMPT_TOKENS + len(doc_indices) - 1)
                // len(doc_indices),
            ),
        )


def wrap_arguments(raw_arguments: str, task: dict) -> tuple[str, bool, str | None]:
    try:
        parsed = json.loads(
            raw_arguments.strip(), object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )
    except ValueError as exc:
        return raw_arguments, False, str(exc)
    if not isinstance(parsed, dict):
        return raw_arguments, False, "arguments output is not a JSON object"
    call = {"name": task["target_tool_schema"]["name"], "arguments": parsed}
    return json.dumps(call, ensure_ascii=False, separators=(",", ":")), True, None


def strict_score(raw: str, task: dict) -> dict:
    try:
        json.loads(
            raw.strip(), object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )
        return reader.score_output(raw, task)
    except ValueError as exc:
        scored = reader.score_output("", task)
        scored["parse_error"] = str(exc)
        scored["schema_error"] = str(exc)
        return scored


def load_existing() -> dict[tuple[str, str], dict]:
    if not OUTPUT.exists():
        return {}
    rows = base.jsonl(OUTPUT)
    keys = [(r["condition"], r["qa_id"]) for r in rows]
    if len(keys) != len(set(keys)):
        raise ValueError("Duplicate condition/task rows in constrained-reader trace")
    return dict(zip(keys, rows))


def run(limit: int | None) -> None:
    corpus = base.load_corpus()
    rankings = reader.prediction_rankings()
    tokenizer, model = reader.load_model()
    existing = load_existing()
    jobs = [(condition, task) for condition in CONDITIONS for task in corpus.tasks]
    jobs = [job for job in jobs if (job[0], job[1]["qa_id"]) not in existing]
    if limit is not None:
        jobs = jobs[:limit]
    with OUTPUT.open("a", encoding="utf-8") as handle:
        for condition, task in tqdm(jobs, desc="selected-tool-arguments"):
            doc_indices = reader.condition_ids(task, condition, rankings, corpus)
            _, prompt_ids, memory_budget = build_constrained_prompt(
                task, doc_indices, corpus, tokenizer
            )
            digest = hashlib.sha256(
                np.asarray(prompt_ids, dtype=np.int32).tobytes()
            ).hexdigest()
            input_ids = torch.tensor([prompt_ids], dtype=torch.long, device="mps")
            attention_mask = torch.ones_like(input_ids)
            begin = time.perf_counter()
            with torch.inference_mode():
                generated = model.generate(
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    do_sample=False,
                    repetition_penalty=1.0,
                    max_new_tokens=reader.MAX_NEW_TOKENS,
                    use_cache=True,
                    pad_token_id=tokenizer.eos_token_id,
                )
            elapsed = time.perf_counter() - begin
            new_ids = generated[0, input_ids.shape[1]:].detach().cpu().tolist()
            raw_arguments = tokenizer.decode(new_ids, skip_special_tokens=True)
            raw, wrapper_valid, wrapper_error = wrap_arguments(raw_arguments, task)
            row = {
                "model": "Qwen/Qwen2.5-1.5B-Instruct",
                "revision": reader.QWEN_REVISION,
                "decoding": "selected-tool arguments-only",
                "condition": condition,
                "qa_id": task["qa_id"],
                "document_indices": doc_indices,
                "document_ids": [corpus.documents[i]["id"] for i in doc_indices],
                "prompt_sha256": digest,
                "input_tokens": len(prompt_ids),
                "memory_token_budget": memory_budget,
                "output_tokens": len(new_ids),
                "generation_seconds": elapsed,
                "raw_argument_output": raw_arguments,
                "wrapper_valid": wrapper_valid,
                "wrapper_error": wrapper_error,
                "raw_output": raw,
                **strict_score(raw, task),
            }
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
            handle.flush()
    if len(load_existing()) == len(CONDITIONS) * len(corpus.tasks):
        summarize()


def summarize() -> None:
    corpus = base.load_corpus()
    tasks = {t["qa_id"]: t for t in corpus.tasks}
    valid_ids, failures = reader.gold_consistency(corpus)
    rows = base.jsonl(OUTPUT)
    expected = {(c, t["qa_id"]) for c in CONDITIONS for t in corpus.tasks}
    keys = {(r["condition"], r["qa_id"]) for r in rows}
    if keys != expected or len(rows) != len(expected):
        raise ValueError(f"Incomplete constrained-reader trace: {len(rows)}/{len(expected)}")
    corrected = []
    for row in rows:
        row = dict(row)
        rescored = strict_score(row["raw_output"], tasks[row["qa_id"]])
        row.update(rescored)
        for key, value in rescored.items():
            if row[key] != value:
                raise ValueError(f"Metric mismatch: {row['condition']}/{row['qa_id']}/{key}")
        parsed = None
        if row.get("wrapper_valid"):
            parsed = json.loads(row["raw_output"])
        if isinstance(parsed, dict) and parsed.get("name") != tasks[row["qa_id"]]["target_tool_schema"]["name"]:
            raise ValueError(f"Selected-name constraint failed: {row['condition']}/{row['qa_id']}")
        corrected.append(row)
    rows = corrected
    OUTPUT.write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in rows))
    original = base.jsonl(base.OUTPUT / "publication_reader_predictions.jsonl")
    original = [
        r for r in original
        if r["condition"] in CONDITIONS and r["qa_id"] in valid_ids
    ]
    constrained = [r for r in rows if r["qa_id"] in valid_ids]
    report = {
        "model": "Qwen/Qwen2.5-1.5B-Instruct",
        "revision": reader.QWEN_REVISION,
        "control": (
            "Selected-tool arguments-only decoding: the interface fixes the observed "
            "tool name before generation, the reader produces one argument object, and "
            "a deterministic wrapper assembles the full call"
        ),
        "instruction": CONSTRAINED_SYSTEM,
        "parser": "Complete JSON; reject duplicate keys and non-JSON numeric constants; no repair",
        "conditions": list(CONDITIONS),
        "gold_schema_consistent": len(valid_ids),
        "gold_schema_inconsistent": failures,
        "completed_by_condition": dict(Counter(r["condition"] for r in rows)),
        "generation_seconds": float(sum(r["generation_seconds"] for r in rows)),
        "prediction_file_sha256": base.sha256(OUTPUT),
        "results_constrained": reader.aggregate(rows, valid_ids),
        "results_original_unconstrained": reader.aggregate(original, valid_ids),
    }
    base.write_json(REPORT, report)
    print(json.dumps(report, ensure_ascii=False, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("run", "summarize"))
    parser.add_argument("--limit", type=int)
    args = parser.parse_args()
    if args.command == "run":
        run(args.limit)
    else:
        summarize()


if __name__ == "__main__":
    main()
