#!/usr/bin/env python3
"""Repeated mismatched-schema CE placebos with request and pool held fixed."""
from __future__ import annotations

import json
import time

import joblib
import numpy as np

import revision_controls as controls
import scar_pair_reproduce as base
import stage2_evaluate as ev

N_PERMUTATIONS = 5


def mismatched_left(current, donor):
    current_request = base.query_text(current)
    donor_schema = donor["target_tool_schema"]
    out = (f"Request: {current_request}\n"
           f"Tool name: {donor_schema.get('name', '')}\n"
           f"Tool description: {donor_schema.get('description', '')}")
    for name, spec in base.properties(donor):
        out += f"\nParameter name: {name}\nParameter description: {spec.get('description', '')}"
    return out


def different_tool_permutation(records, seed):
    rng = np.random.default_rng(seed)
    names = [r["task"]["target_tool_schema"]["name"] for r in records]
    for _ in range(10000):
        donor = rng.permutation(len(records))
        if all(names[i] != names[int(donor[i])] for i in range(len(records))):
            return donor
    raise RuntimeError(f"Could not build different-tool permutation for seed {seed}")


def main():
    records = joblib.load(base.CACHE / "stage2_records.joblib")
    corpus = base.load_corpus()
    documents = [d["text"] for d in corpus.documents]
    model = ev.load_ce()
    predictions, fits, raw_scores, runs = [], [], [], []
    for permutation_index in range(N_PERMUTATIONS):
        seed = base.SEED + 1200 + permutation_index
        donor = different_tool_permutation(records, seed)
        method = f"Mismatched-schema-CE-{permutation_index + 1}"
        started = time.perf_counter()
        pair_count = 0
        for i, record in enumerate(records):
            left = mismatched_left(record["task"], records[int(donor[i])]["task"])
            pool = record["narrow"]
            pairs = [(left, documents[int(index)]) for index in pool]
            score = np.asarray(model.predict(pairs, batch_size=128,
                                             show_progress_bar=False, convert_to_numpy=True),
                               dtype=np.float32).reshape(-1)
            if not np.isfinite(score).all():
                raise ValueError(record["qa_id"])
            second = ev.extend_view(record["train_ids"], pool, score)
            record["ce_narrow"] = np.column_stack(
                (record["ce_narrow"][:, :3], second)).astype(np.float32)
            raw_scores.append({"permutation": permutation_index + 1, "seed": seed,
                               "qa_id": record["qa_id"],
                               "donor_qa_id": records[int(donor[i])]["qa_id"],
                               "narrow_document_indices": [int(x) for x in pool],
                               "mismatched_schema_ce_logits": [float(x) for x in score]})
            pair_count += len(pairs)
            if (i + 1) % 50 == 0:
                print(f"permutation {permutation_index + 1}/{N_PERMUTATIONS}: "
                      f"scored {i+1}/{len(records)}", flush=True)
        scoring_seconds = time.perf_counter() - started
        run_predictions = []
        for fold, (train, test) in enumerate(ev.protocols(records)["stratified"]):
            scale, clf, diagnostic = controls.fit(records, train, "SCAR-Pair-refit")
            fits.append({"permutation": permutation_index + 1, "seed": seed,
                         "fold": fold, **diagnostic})
            for index in test:
                r = records[int(index)]
                ids = r["broad"]
                scores = clf.decision_function(
                    controls.features(r, ids, "SCAR-Pair-refit") / scale)
                order = ids[np.lexsort((np.arange(len(ids)), -scores))]
                row = {"protocol": "stratified", "fold": fold, "method": method,
                       "permutation": permutation_index + 1, "seed": seed,
                       "qa_id": r["qa_id"],
                       "top10_document_indices": [int(v) for v in order[:10]],
                       **ev.task_metrics(order, r["gold"])}
                predictions.append(row)
                run_predictions.append(row)
        aggregates = {m: float(np.mean([r[m] for r in run_predictions]))
                      for m in ("hit", "recall", "complete", "mrr", "ndcg")}
        runs.append({"permutation": permutation_index + 1, "seed": seed,
                     "method": method, "ce_pairs": pair_count,
                     "scoring_seconds": scoring_seconds, "aggregates": aggregates,
                     "donors": [{"qa_id": r["qa_id"],
                                  "donor_qa_id": records[int(donor[i])]["qa_id"]}
                                 for i, r in enumerate(records)]})
        print(json.dumps({"method": method, "ce_pairs": pair_count,
                          "scoring_seconds": scoring_seconds,
                          "aggregates": aggregates}, indent=2), flush=True)
    out = base.OUTPUT
    (out / "revision_mismatch_ce_scores.jsonl").write_text(
        "".join(json.dumps(r) + "\n" for r in raw_scores), encoding="utf-8")
    (out / "revision_mismatch_predictions.jsonl").write_text(
        "".join(json.dumps(r) + "\n" for r in predictions), encoding="utf-8")
    report = {
        "control": "Five prespecified different-tool schema permutations (seeds 20261930--20261934); current request and broad/narrow candidate pools retained; only schema CE triplet replaced",
        "permutations": N_PERMUTATIONS,
        "total_ce_pairs": sum(r["ce_pairs"] for r in runs),
        "total_scoring_seconds": sum(r["scoring_seconds"] for r in runs),
        "runs": runs,
        "fits": fits,
        "aggregate_ranges": {
            metric: [min(r["aggregates"][metric] for r in runs),
                     max(r["aggregates"][metric] for r in runs)]
            for metric in ("hit", "recall", "complete", "mrr", "ndcg")
        },
    }
    (out / "revision_mismatch_report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"permutations": N_PERMUTATIONS,
                      "total_ce_pairs": report["total_ce_pairs"],
                      "total_scoring_seconds": report["total_scoring_seconds"],
                      "aggregate_ranges": report["aggregate_ranges"]}, indent=2))


if __name__ == "__main__":
    main()
