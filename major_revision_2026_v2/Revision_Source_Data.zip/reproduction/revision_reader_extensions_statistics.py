#!/usr/bin/env python3
"""Component-aware inference for constrained and multi-reader extensions."""

from __future__ import annotations

import json
from collections import defaultdict

import joblib

import publication_analysis as pub
import reader_reproduce as reader
import scar_pair_reproduce as base
from stage2_evaluate import shared_source_groups


CONDITIONS = ("No-memory", "Query-Fuse-strict", "SCAR-Pair", "Oracle-Gold")
METRICS = ("memory_argument", "memory_call", "full_call")


def load(path):
    return [json.loads(s) for s in path.read_text().splitlines() if s.strip()]


def indexed(rows, valid_ids):
    out = defaultdict(dict)
    for row in rows:
        if row["qa_id"] not in valid_ids or row["condition"] not in CONDITIONS:
            continue
        out[row["condition"]][row["qa_id"]] = {
            "schema": float(row["schema_valid"]),
            "memory_argument": float(row["memory_argument_em"]),
            "memory_call": float(row["memory_call_em"]),
            "full_call": float(row["full_call_em"]),
        }
    return out


def main():
    corpus = base.load_corpus()
    valid_ids, _ = reader.gold_consistency(corpus)
    records = joblib.load(base.CACHE / "stage2_records.joblib")
    labels = shared_source_groups(records)
    components = {r["qa_id"]: int(c) for r, c in zip(records, labels)}
    sources = {
        "Qwen2.5-1.5B unconstrained": indexed(
            load(base.OUTPUT / "publication_reader_predictions.jsonl"), valid_ids
        ),
        "Qwen2.5-1.5B selected-tool-arguments": indexed(
            load(base.OUTPUT / "revision_constrained_reader_predictions.jsonl"), valid_ids
        ),
        "Qwen2.5-3B 4-bit": indexed(
            load(base.OUTPUT / "revision_multireader_qwen25_3b_predictions.jsonl"), valid_ids
        ),
        "Phi-3.5-mini 4-bit": indexed(
            load(base.OUTPUT / "revision_multireader_phi35_mini_predictions.jsonl"), valid_ids
        ),
    }
    results = []
    seed_offset = 0
    for reader_name, by_condition in sources.items():
        for left, right in (
            ("SCAR-Pair", "No-memory"),
            ("SCAR-Pair", "Query-Fuse-strict"),
            ("Oracle-Gold", "SCAR-Pair"),
        ):
            paired = pub.paired(
                by_condition[left], by_condition[right], METRICS,
                components, base.SEED + 1400 + seed_offset,
            )
            results.extend({
                "domain": "within_reader", "reader": reader_name,
                "left": left, "right": right, **row,
            } for row in paired)
            seed_offset += 1
    original = sources["Qwen2.5-1.5B unconstrained"]
    constrained = sources["Qwen2.5-1.5B selected-tool-arguments"]
    for condition in CONDITIONS:
        paired = pub.paired(
            constrained[condition], original[condition],
            ("schema", "memory_argument", "full_call"),
            components, base.SEED + 1400 + seed_offset,
        )
        results.extend({
            "domain": "constraint_effect", "reader": "Qwen2.5-1.5B",
            "condition": condition, "left": "selected-tool-arguments",
            "right": "unconstrained", **row,
        } for row in paired)
        seed_offset += 1
    report = {
        "method": (
            "10,000 shared-source-component bootstrap resamples; 50,000 joint "
            "component sign flips; Holm within each three-metric family; fixed predictions"
        ),
        "gold_schema_consistent_tasks": len(valid_ids),
        "post_hoc": True,
        "results": results,
    }
    base.write_json(base.OUTPUT / "revision_reader_extensions_statistics.json", report)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
