#!/usr/bin/env python3
"""Post-review controls from frozen stage-two features; no new CE inference.

The query replay is an equal-width counterfactual: it copies the request CE
score/rank/mask into the schema CE coordinates. It does not test a random or
mismatched schema, and its duplicated values contain no new interaction signal.
"""
from __future__ import annotations

import json
import warnings
from pathlib import Path

import joblib
import numpy as np
from sklearn.exceptions import ConvergenceWarning
from sklearn.linear_model import LogisticRegression

import scar_pair_reproduce as base
import stage2_evaluate as ev

OUT = Path(__file__).resolve().parent / "output"
VARIANTS = ("SCAR-Pair-refit", "Query-CE-replay", "No-insertion-refit",
            "Query-Pair-no-insertion")


def features(record, ids, variant):
    pos = {int(d): i for i, d in enumerate(record["train_ids"])}
    take = np.asarray([pos[int(d)] for d in ids], dtype=np.int32)
    x = np.column_stack((record["light"], record["ce_narrow"]))[take].astype(np.float32)
    if variant == "Query-Pair-no-insertion":
        return np.column_stack((record["light"][take][:, [0, 1, 8, 9]],
                                record["ce_query_narrow"][take])).astype(np.float32)
    if variant == "Query-CE-replay":
        x[:, 15:18] = x[:, 12:15]
    return x


def fit(records, train, variant, c=1.0):
    differences, labels, weights = [], [], []
    used, skipped = 0, 0
    for index in train:
        record = records[int(index)]
        ids = (record["strict"] if variant == "Query-Pair-no-insertion" else
               record["broad"] if variant == "No-insertion-refit" else record["train_ids"])
        gold = np.isin(ids, record["gold"])
        if not gold.any():
            skipped += 1
            continue
        if gold.all():
            raise ValueError(f"No negatives for {record['qa_id']}")
        x = features(record, ids, variant)
        delta = (x[gold, None, :] - x[None, ~gold, :]).reshape(-1, x.shape[1])
        differences.extend((delta, -delta))
        labels.extend((np.ones(len(delta), dtype=np.int8), np.zeros(len(delta), dtype=np.int8)))
        weights.extend((np.full(len(delta), 1 / (2 * len(delta))),) * 2)
        used += 1
    x = np.vstack(differences)
    y = np.concatenate(labels)
    w = np.concatenate(weights)
    scale = x.std(axis=0, ddof=0)
    scale[scale == 0] = 1
    clf = LogisticRegression(C=c, fit_intercept=False, class_weight=None,
                             solver="lbfgs", tol=1e-7, max_iter=2000,
                             random_state=base.SEED)
    with warnings.catch_warnings():
        warnings.simplefilter("error", ConvergenceWarning)
        clf.fit(x / scale, y, sample_weight=w)
    return scale, clf, {"training_queries": used, "skipped_zero_hit": skipped,
                        "mirrored_rows": len(x), "weight_sum": float(w.sum()),
                        "iterations": int(clf.n_iter_[0])}


def main():
    records = joblib.load(base.CACHE / "stage2_records.joblib")
    predictions, fits = [], []
    for protocol, folds in ev.protocols(records).items():
        for fold, (train, test) in enumerate(folds):
            for variant in VARIANTS:
                if protocol != "stratified" and variant not in ("No-insertion-refit", "Query-Pair-no-insertion"):
                    continue
                print(protocol, fold, variant, flush=True)
                scale, clf, diagnostic = fit(records, train, variant)
                fits.append({"protocol": protocol, "fold": fold, "variant": variant, **diagnostic})
                for index in test:
                    r = records[int(index)]
                    ids = r["strict"] if variant == "Query-Pair-no-insertion" else r["broad"]
                    scores = clf.decision_function(features(r, ids, variant) / scale)
                    if not np.isfinite(scores).all():
                        raise ValueError(r["qa_id"])
                    order = ids[np.lexsort((np.arange(len(ids)), -scores))]
                    predictions.append({"protocol": protocol, "fold": fold,
                                        "method": variant, "qa_id": r["qa_id"],
                                        "top10_document_indices": [int(v) for v in order[:10]],
                                        **ev.task_metrics(order, r["gold"])})
    pred_path = OUT / "revision_controls_predictions.jsonl"
    pred_path.write_text("".join(json.dumps(r) + "\n" for r in predictions), encoding="utf-8")
    aggregates = []
    for protocol, method in sorted({(r["protocol"], r["method"]) for r in predictions}):
        subset = [r for r in predictions if r["protocol"] == protocol and r["method"] == method]
        aggregates.append({"protocol": protocol, "method": method, "tasks": len(subset),
                           **{m: float(np.mean([r[m] for r in subset]))
                              for m in ("hit", "recall", "complete", "mrr", "ndcg")}})
    report = {"description": "Frozen-feature post-review controls; original method is unchanged",
              "query_replay": "Schema CE triplet replaced by identical request CE triplet; same 18 columns and candidate pool",
              "no_insertion": "Training uses only gold sources already in each method's ordinary pool (broad for SCAR, strict request-only for Query-Pair); zero-hit training tasks are skipped; all test tasks retained",
              "aggregates": aggregates, "fits": fits}
    (OUT / "revision_controls_report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(aggregates, indent=2))


if __name__ == "__main__":
    main()
