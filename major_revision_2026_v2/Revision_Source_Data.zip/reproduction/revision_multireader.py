#!/usr/bin/env python3
"""Matched multi-reader replication on four frozen retrieval conditions.

The same task set, ranked document IDs, textual prompt convention, greedy
decoding, strict parser, schema validator, and exact-match scorer are used for
each reader.  Token truncation is recomputed with each reader's tokenizer.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import time
from collections import Counter
from pathlib import Path

import numpy as np
from huggingface_hub import snapshot_download
from mlx_lm import generate, load
from tqdm import tqdm

import reader_reproduce as reader
import scar_pair_reproduce as base
from reader_parser_audit import reject_constant, unique_object


CONDITIONS = ("No-memory", "Query-Fuse-strict", "SCAR-Pair", "Oracle-Gold")
MODELS = {
    "qwen25_3b": {
        "repo": "mlx-community/Qwen2.5-3B-Instruct-4bit",
        "revision": "4f83f8f146fdf28b512a06562b671d7af4fab457",
        "display": "Qwen2.5-3B-Instruct (4-bit)",
        "family": "Qwen2.5",
    },
    "phi35_mini": {
        "repo": "mlx-community/Phi-3.5-mini-instruct-4bit",
        "revision": "7b2052fd882fe017300d4d42a4eb06a27b816af4",
        "display": "Phi-3.5-mini-instruct (4-bit)",
        "family": "Phi-3.5",
    },
}


def paths(model_key: str) -> tuple[Path, Path]:
    stem = f"revision_multireader_{model_key}"
    return base.OUTPUT / f"{stem}_predictions.jsonl", base.OUTPUT / f"{stem}_report.json"


def existing_rows(path: Path) -> dict[tuple[str, str], dict]:
    if not path.exists():
        return {}
    rows = base.jsonl(path)
    keys = [(r["condition"], r["qa_id"]) for r in rows]
    if len(keys) != len(set(keys)):
        raise ValueError(f"Duplicate multi-reader rows in {path}")
    return dict(zip(keys, rows))


def strict_score(raw: str, task: dict) -> dict:
    try:
        json.loads(
            raw.strip(), object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )
        return reader.score_output(raw, task)
    except ValueError as exc:
        scored = reader.score_output("", task)
        scored["parse_error"] = str(exc)
        scored["schema_error"] = str(exc)
        return scored


def run(model_key: str, limit: int | None) -> None:
    spec = MODELS[model_key]
    snapshot = snapshot_download(repo_id=spec["repo"], revision=spec["revision"])
    model, tokenizer = load(snapshot)
    # Some MLX community tokenizer wrappers expose only the base end-of-text ID
    # in ``eos_token_ids`` even when the chat template terminates assistant turns
    # with a different EOS token (Phi-3.5 uses <|end|>).  Include the declared
    # tokenizer EOS so generation stops at the first completed assistant turn.
    if getattr(tokenizer, "eos_token_id", None) is not None:
        tokenizer.eos_token_ids.add(int(tokenizer.eos_token_id))
    corpus = base.load_corpus()
    rankings = reader.prediction_rankings()
    output, _ = paths(model_key)
    existing = existing_rows(output)
    jobs = [(condition, task) for condition in CONDITIONS for task in corpus.tasks]
    jobs = [job for job in jobs if (job[0], job[1]["qa_id"]) not in existing]
    if limit is not None:
        jobs = jobs[:limit]
    with output.open("a", encoding="utf-8") as handle:
        for condition, task in tqdm(jobs, desc=model_key):
            doc_indices = reader.condition_ids(task, condition, rankings, corpus)
            _, prompt_ids, memory_budget = reader.build_prompt(
                task, doc_indices, corpus, tokenizer
            )
            digest = hashlib.sha256(
                np.asarray(prompt_ids, dtype=np.int32).tobytes()
            ).hexdigest()
            begin = time.perf_counter()
            raw = generate(
                model,
                tokenizer,
                prompt=prompt_ids,
                max_tokens=reader.MAX_NEW_TOKENS,
                verbose=False,
            )
            elapsed = time.perf_counter() - begin
            output_tokens = len(tokenizer.encode(raw, add_special_tokens=False))
            row = {
                "model_key": model_key,
                "model": spec["repo"],
                "revision": spec["revision"],
                "quantization": "4-bit MLX",
                "condition": condition,
                "qa_id": task["qa_id"],
                "document_indices": doc_indices,
                "document_ids": [corpus.documents[i]["id"] for i in doc_indices],
                "prompt_sha256": digest,
                "input_tokens": len(prompt_ids),
                "memory_token_budget": memory_budget,
                "output_tokens": output_tokens,
                "generation_seconds": elapsed,
                "raw_output": raw,
                **strict_score(raw, task),
            }
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
            handle.flush()
    if len(existing_rows(output)) == len(CONDITIONS) * len(corpus.tasks):
        summarize(model_key)


def summarize(model_key: str) -> None:
    spec = MODELS[model_key]
    corpus = base.load_corpus()
    tasks = {t["qa_id"]: t for t in corpus.tasks}
    valid_ids, failures = reader.gold_consistency(corpus)
    output, report_path = paths(model_key)
    rows = base.jsonl(output)
    expected = {(c, t["qa_id"]) for c in CONDITIONS for t in corpus.tasks}
    keys = {(r["condition"], r["qa_id"]) for r in rows}
    if keys != expected or len(rows) != len(expected):
        raise ValueError(f"Incomplete {model_key} trace: {len(rows)}/{len(expected)}")
    corrected = []
    for row in rows:
        row = dict(row)
        rescored = strict_score(row["raw_output"], tasks[row["qa_id"]])
        row.update(rescored)
        for key, value in rescored.items():
            if row[key] != value:
                raise ValueError(f"Metric mismatch: {model_key}/{row['condition']}/{row['qa_id']}/{key}")
        corrected.append(row)
    rows = corrected
    output.write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in rows))
    report = {
        "model_key": model_key,
        **spec,
        "quantization": "4-bit MLX",
        "parser": "Complete JSON; reject duplicate keys and non-JSON numeric constants; no repair",
        "conditions": list(CONDITIONS),
        "prompt_and_evaluation": (
            "Same task set, ranked document IDs, textual instructions, five-memory "
            "budget, greedy decoding, strict parser, recursive validator, and exact-match "
            "scorer as the primary reader; token truncation uses this model's tokenizer"
        ),
        "gold_schema_consistent": len(valid_ids),
        "gold_schema_inconsistent": failures,
        "completed_by_condition": dict(Counter(r["condition"] for r in rows)),
        "generation_seconds": float(sum(r["generation_seconds"] for r in rows)),
        "prediction_file_sha256": base.sha256(output),
        "results_consistent_tasks": reader.aggregate(rows, valid_ids),
        "results_all_tasks": reader.aggregate(rows, None),
    }
    base.write_json(report_path, report)
    print(json.dumps(report, ensure_ascii=False, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("run", "summarize"))
    parser.add_argument("--model", choices=tuple(MODELS), required=True)
    parser.add_argument("--limit", type=int)
    args = parser.parse_args()
    if args.command == "run":
        run(args.model, args.limit)
    else:
        summarize(args.model)


if __name__ == "__main__":
    main()
