#!/usr/bin/env python3
"""Component-aware inference for the post-review controls and reader audit."""
import json
from collections import defaultdict

import joblib
import numpy as np

import publication_analysis as pub
import scar_pair_reproduce as base
from stage2_evaluate import shared_source_groups


def rows(path):
    return [json.loads(s) for s in path.read_text().splitlines() if s.strip()]


def main():
    records = joblib.load(base.CACHE / "stage2_records.joblib")
    labels = shared_source_groups(records)
    components = {r["qa_id"]: int(c) for r, c in zip(records, labels)}
    original = rows(base.OUTPUT / "retrieval_predictions.jsonl") + rows(base.OUTPUT / "publication_pair_controls_predictions.jsonl")
    revision = rows(base.OUTPUT / "revision_controls_predictions.jsonl") + rows(base.OUTPUT / "revision_mismatch_predictions.jsonl")
    lookup = defaultdict(dict)
    for r in original + revision:
        lookup[(r["protocol"], r["method"])][r["qa_id"]] = r
    mismatch_methods = sorted({r["method"] for r in revision
                               if r["method"].startswith("Mismatched-schema-CE-")})
    contrasts = []
    counter = 0
    for protocol in ("stratified", "unseen_tool", "shared_source", "leave_source_out"):
        pairs = [("SCAR-Pair", "No-insertion-refit"),
                 ("No-insertion-refit", "Query-Pair-no-insertion")]
        if protocol == "stratified":
            pairs.extend([("SCAR-Pair", "Query-CE-replay"),
                          ("No-insertion-refit", "Query-Pair-strict")])
            pairs.extend(("SCAR-Pair", method) for method in mismatch_methods)
        for left, right in pairs:
            results = pub.paired(lookup[(protocol, left)], lookup[(protocol, right)],
                                 ("recall", "complete", "ndcg"), components,
                                 base.SEED + 900 + counter)
            contrasts.extend({"domain": "retrieval", "protocol": protocol,
                              "left": left, "right": right, **x} for x in results)
            counter += 1
    reader_rows = rows(base.OUTPUT / "revision_reader_audit.jsonl")
    by_condition = defaultdict(dict)
    for r in reader_rows:
        by_condition[r["condition"]][r["qa_id"]] = r
    for condition in ("SCAR-Pair", "Query-Fuse-strict", "Oracle-Gold"):
        same = by_condition[condition]
        left = {q: {"schema": r["locked_schema_valid"],
                    "memory_call": r["locked_memory_call_em"],
                    "full_call": r["locked_full_call_em"]} for q, r in same.items()}
        right = {q: {"schema": r["original_schema_valid"],
                     "memory_call": r["original_memory_call_em"],
                     "full_call": r["original_full_call_em"]} for q, r in same.items()}
        results = pub.paired(left, right, ("schema", "memory_call", "full_call"),
                             components, base.SEED + 900 + counter)
        contrasts.extend({"domain": "reader_name_lock", "condition": condition,
                          "left": "locked", "right": "original", **x} for x in results)
        counter += 1
    report = {"method": "10,000 shared-source-component bootstrap resamples; 50,000 joint component sign flips; Holm within each three-metric family; fixed predictions",
              "post_hoc": True, "results": contrasts}
    (base.OUTPUT / "revision_statistics_report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(contrasts, indent=2))


if __name__ == "__main__":
    main()
