#!/usr/bin/env python3
"""Audit frozen reader traces and a deterministic selected-tool-name lock.

The lock changes only the parsed output name after generation. It is a
counterfactual error diagnostic, not constrained decoding or a new reader run.
"""
from __future__ import annotations

import json
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

import reader_reproduce as reader
import scar_pair_reproduce as base

OUT = Path(__file__).resolve().parent / "output"


def normalized(value):
    if isinstance(value, str):
        return " ".join(unicodedata.normalize("NFKC", value).casefold().split())
    return value


def main():
    corpus = base.load_corpus()
    tasks = {t["qa_id"]: t for t in corpus.tasks}
    valid, _ = reader.gold_consistency(corpus)
    source_id_to_index = {d["id"]: i for i, d in enumerate(corpus.documents)}
    rows = [json.loads(s) for s in (OUT / "publication_reader_predictions.jsonl").read_text().splitlines() if s.strip()]
    details, groups = [], defaultdict(list)
    for r in rows:
        qid = r["qa_id"]
        if qid not in valid or qid not in tasks:
            continue
        task = tasks[qid]
        selected = task["target_tool_schema"]["name"]
        parsed, _ = reader.parse_exact(r["raw_output"])
        old_name = parsed.get("name") if isinstance(parsed, dict) else None
        wrong_name = bool(r["json_valid"] and old_name != selected)
        locked = None
        if r["json_valid"] and isinstance(parsed, dict):
            fixed = dict(parsed)
            fixed["name"] = selected
            locked = reader.score_output(json.dumps(fixed, ensure_ascii=False), task)
        gold_ids = [source_id_to_index[s] for s in task.get("source_conversation_ids", [])
                    if s in source_id_to_index]
        retrieval_hit = bool(set(gold_ids) & set(r["document_indices"]))
        gold_args = task["tool_call"].get("arguments", {}) or {}
        pred_args = parsed.get("arguments", {}) if isinstance(parsed, dict) else {}
        if not isinstance(pred_args, dict):
            pred_args = {}
        grounding = task["tool_call"].get("grounding_info", {}) or {}
        needed = [k for k, info in grounding.items() if info.get("type") in {"explicit", "inferred"}]
        mismatch = [k for k in needed if not r["memory_argument_matches"].get(k, False)]
        normalization_candidate = bool(mismatch) and all(
            k in pred_args and k in gold_args and normalized(pred_args[k]) == normalized(gold_args[k])
            for k in mismatch
        )
        if not r["json_valid"]:
            primary_error = "invalid_json"
        elif wrong_name:
            primary_error = "wrong_tool_name"
        elif not retrieval_hit and r["condition"] != "No-memory":
            primary_error = "gold_source_absent_top5"
        elif mismatch and normalization_candidate:
            primary_error = "surface_normalization_candidate"
        elif mismatch:
            primary_error = "argument_extraction_or_inference"
        elif not r["schema_valid"]:
            primary_error = "schema_validation"
        elif not r["full_call_em"]:
            primary_error = "other_call_mismatch"
        else:
            primary_error = "full_call_match"
        d = {"condition": r["condition"], "qa_id": qid,
             "selected_tool": selected, "predicted_tool": old_name,
             "gold_in_top5": retrieval_hit, "gold_source_count": len(gold_ids),
             "wrong_tool_name": wrong_name, "normalization_candidate": normalization_candidate,
             "primary_error": primary_error, "original_schema_valid": bool(r["schema_valid"]),
             "locked_schema_valid": False if locked is None else bool(locked["schema_valid"]),
             "original_memory_call_em": bool(r["memory_call_em"]),
             "locked_memory_call_em": False if locked is None else bool(locked["memory_call_em"]),
             "original_full_call_em": bool(r["full_call_em"]),
             "locked_full_call_em": False if locked is None else bool(locked["full_call_em"]),
             "original_memory_argument_em": float(r["memory_argument_em"]),
             "locked_memory_argument_em": float(r["memory_argument_em"]) if locked is None else float(locked["memory_argument_em"]),
             "document_ids": r["document_ids"], "raw_output": r["raw_output"]}
        details.append(d)
        groups[r["condition"]].append(d)
    aggregates = []
    for condition, subset in groups.items():
        aggregates.append({"condition": condition, "tasks": len(subset),
                           "wrong_tool_name": sum(x["wrong_tool_name"] for x in subset),
                           "gold_source_absent_top5": sum(not x["gold_in_top5"] for x in subset),
                           "normalization_candidates": sum(x["normalization_candidate"] for x in subset),
                           "primary_errors": dict(Counter(x["primary_error"] for x in subset)),
                           **{name: float(np.mean([x[name] for x in subset if x[name] is not None]))
                              for name in ("original_schema_valid", "locked_schema_valid",
                                           "original_memory_call_em", "locked_memory_call_em",
                                           "original_full_call_em", "locked_full_call_em")}})
    (OUT / "revision_reader_audit.jsonl").write_text(
        "".join(json.dumps(x, ensure_ascii=False) + "\n" for x in details), encoding="utf-8")
    report = {"design": "Post-generation name lock on frozen Qwen outputs; arguments unchanged; 385 gold-schema-consistent tasks",
              "interpretation": "Diagnostic upper bound for eliminating tool-name errors in these fixed outputs; not constrained decoding",
              "normalization": "NFKC, case-fold, and whitespace collapse only; candidates are not manually adjudicated",
              "aggregates": aggregates}
    (OUT / "revision_reader_audit_report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(aggregates, indent=2))


if __name__ == "__main__":
    main()
