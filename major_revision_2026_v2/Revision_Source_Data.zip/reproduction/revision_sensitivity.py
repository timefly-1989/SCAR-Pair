#!/usr/bin/env python3
"""One-factor regularization and missing-CE-floor sensitivity on fixed folds."""
import json

import joblib
import numpy as np

import revision_controls as ctl
import scar_pair_reproduce as base
import stage2_evaluate as ev


def evaluate(records, label, c):
    predictions, fits = [], []
    for fold, (train, test) in enumerate(ev.protocols(records)["stratified"]):
        scale, clf, diagnostic = ctl.fit(records, train, "SCAR-Pair-refit", c=c)
        fits.append({"fold": fold, "C": c,
                     "effective_lambda": 1 / (2 * diagnostic["training_queries"] * c),
                     **diagnostic})
        for index in test:
            r = records[int(index)]
            ids = r["broad"]
            scores = clf.decision_function(ctl.features(r, ids, "SCAR-Pair-refit") / scale)
            order = ids[np.lexsort((np.arange(len(ids)), -scores))]
            predictions.append({"method": label, "protocol": "stratified", "fold": fold,
                                "qa_id": r["qa_id"], "top10_document_indices": [int(v) for v in order[:10]],
                                **ev.task_metrics(order, r["gold"])})
    return predictions, fits


def main():
    records = joblib.load(base.CACHE / "stage2_records.joblib")
    all_predictions, all_fits = [], []
    for label, c in (("C=0.1", 0.1), ("C=10", 10.0)):
        print(label, flush=True)
        preds, fits = evaluate(records, label, c)
        all_predictions += preds
        all_fits += [{"method": label, **x} for x in fits]
    # The cached floor is min(logit)-1e-6. Change only unavailable score cells.
    for r in records:
        for score, mask in ((0, 2), (3, 5)):
            missing = r["ce_narrow"][:, mask] == 0
            r["ce_narrow"][missing, score] -= (1e-3 - 1e-6)
    print("epsilon=1e-3", flush=True)
    preds, fits = evaluate(records, "epsilon=1e-3", 1.0)
    all_predictions += preds
    all_fits += [{"method": "epsilon=1e-3", **x} for x in fits]
    aggregates = []
    for label in ("C=0.1", "C=10", "epsilon=1e-3"):
        subset = [r for r in all_predictions if r["method"] == label]
        aggregates.append({"method": label, "tasks": len(subset),
                           **{m: float(np.mean([r[m] for r in subset]))
                              for m in ("recall", "complete", "ndcg")}})
    (base.OUTPUT / "revision_sensitivity_predictions.jsonl").write_text(
        "".join(json.dumps(r) + "\n" for r in all_predictions))
    (base.OUTPUT / "revision_sensitivity_report.json").write_text(json.dumps({
        "design": "Post hoc one-factor sensitivity for C and epsilon_u; C=1, epsilon_u=1e-6 baseline is the fixed primary configuration; the joint d1/d2 grid remains in the original depth report",
        "aggregates": aggregates, "fits": all_fits}, indent=2) + "\n")
    print(json.dumps(aggregates, indent=2))


if __name__ == "__main__":
    main()
