"""Rebuild SCAR-Pair manuscript figures from the authoritative reproduction JSONs.

Every numeric cell is loaded from reproduction/output/*.json (the same values
published in tables/generated/*.tex). No bitmap retouching, no statistical
re-estimation, no reused legacy artwork: the paired-difference forest panels
are drawn directly from publication_statistics_report.json difference/ci95.
"""
from pathlib import Path
import argparse, csv, json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from matplotlib.lines import Line2D
from audit_panel_alignment import require_matplotlib_panel_alignment

ROOT = Path(__file__).resolve().parents[1]
FIGURES = ROOT / "figures"
OUT = FIGURES / "vector"
DATA = ROOT / "reproduction" / "figure_data"
QA = ROOT / "build" / "figure_qa"
OUT.mkdir(parents=True, exist_ok=True)
DATA.mkdir(parents=True, exist_ok=True)
QA.mkdir(parents=True, exist_ok=True)
REPRO = ROOT / "reproduction" / "output"

def load_json(name):
    return json.loads((REPRO / name).read_text())

STATS_META = load_json("publication_statistics_report.json")
STATS = STATS_META["results"]
RETR = load_json("retrieval_report.json")
PAIR = load_json("publication_pair_controls_report.json")
EXTRA = load_json("publication_extra_summaries.json")
READER = load_json("publication_reader_report.json")
STAGE1 = load_json("stage1_report.json")

AGG = {(r["protocol"], r["method"]): r for r in RETR["aggregates"]}
AGG.update({(r["protocol"], r["method"]): r for r in PAIR["aggregates"]})
MACRO = {m["method"]: m for m in RETR["leave_source_out_source_macro"]}
MACRO.update({m["method"]: m for m in EXTRA["source_macro"]})
CANDIDATES = {r["candidate_set"]: r["reproduced"] for r in STAGE1["candidate_audit"]}
READER_CONSISTENT = {r["condition"]: r for r in READER["consistent"]}

def diff_row(protocol, right, metric):
    for r in STATS:
        if (r["domain"] == "retrieval" and r["protocol"] == protocol
                and r["left"] == "SCAR-Pair" and r["right"] == right
                and r["metric"] == metric):
            return r
    raise KeyError((protocol, right, metric))

def stat_row(protocol, left, right, metric):
    for r in STATS:
        if (r["domain"] == "retrieval" and r["protocol"] == protocol
                and r["left"] == left and r["right"] == right
                and r["metric"] == metric):
            return r
    raise KeyError((protocol, left, right, metric))

def check_loaded_values():
    """Guard against silently reading stale or wrong cells."""
    s = lambda m: AGG[("stratified", m)]
    for m, triple in [("SCAR-Pair", (0.450, 0.427, 0.365)),
                      ("Query-Pair-strict", (0.396, 0.371, 0.325)),
                      ("Query-Fuse-strict", (0.388, 0.363, 0.316)),
                      ("CE-Calibrated-Broad", (0.419, 0.396, 0.334)),
                      ("SCAR-Fuse", (0.436, 0.414, 0.353))]:
        r = s(m)
        assert (round(r["recall"], 3), round(r["complete"], 3), round(r["ndcg"], 3)) == triple, m
    lso = lambda m: AGG[("leave_source_out", m)]
    for m, quad in [("SCAR-Pair", (0.418, 0.317, 0.346, 0.268)),
                    ("Query-Pair-strict", (0.401, 0.319, 0.328, 0.267)),
                    ("Query-Fuse-strict", (0.379, 0.300, 0.319, 0.263)),
                    ("SCAR-Fuse", (0.409, 0.314, 0.338, 0.263)),
                    ("CE-Calibrated-Broad", (0.430, 0.310, 0.341, 0.247))]:
        assert (round(lso(m)["recall"], 3), round(MACRO[m]["recall"], 3),
                round(lso(m)["ndcg"], 3), round(MACRO[m]["ndcg"], 3)) == quad, m
    for cond, pair in [("No-memory", (0.977, 0.092)), ("Query-Fuse-strict", (0.623, 0.126)),
                       ("SCAR-Pair", (0.616, 0.108)), ("Oracle-Gold", (0.616, 0.150))]:
        r = READER_CONSISTENT[cond]
        assert (round(r["schema_validity"], 3), round(r["memory_argument_em"], 3)) == pair, cond
        assert r["tasks"] == 385
    assert round(CANDIDATES["request-only depth-200 union"]["recall"], 3) == 0.765
    assert round(CANDIDATES["schema-aware depth-200 union"]["recall"], 3) == 0.832
    assert round(CANDIDATES["schema-aware depth-200 union"]["mean_size"], 1) == 478.2
    assert round(CANDIDATES["CE depth-50 union"]["mean_size"], 1) == 124.7
    assert round(AGG[("stratified", "CE-Query-Calibrated-Broad")]["recall"], 3) == 0.382
    assert round(AGG[("stratified", "CE-Query-Calibrated-Broad")]["ndcg"], 3) == 0.311
    assert len(STATS) == 84
    assert len(RETR["feature_names"]) == 18
    audit = STAGE1["data_audit"]
    assert audit["memory_documents"] == 19661 and audit["released_tasks"] == 400
    assert audit["evidence_tasks"] == 391 and len(audit["empty_source_task_ids"]) == 9
    assert "10000" in STATS_META["bootstrap"] and "50000" in STATS_META["randomization"]

check_loaded_values()

W = 136 / 25.4
C = dict(ink="#24313A", blue="#3B6F93", bluebg="#EAF2F8",
         gold="#A67C2E", goldbg="#FFF3D6", green="#437F68",
         greenbg="#E8F3EE", purple="#80608F", purplebg="#F2EAF5",
         gray="#687782", graybg="#F2F4F5")
METHODS = ["Query-Fuse", "CE-Calibrated-Broad", "SCAR-Fuse", "SCAR-Pair"]
MC = ["#687782", "#D55E00", "#0072B2", "#009E73"]
MINUS = "\u2212"
plt.rcParams.update({"font.family":"sans-serif", "font.sans-serif":["DejaVu Sans"], "font.size":8,
    "axes.titlesize":8, "axes.labelsize":8, "xtick.labelsize":7,
    "ytick.labelsize":7, "legend.fontsize":7, "axes.linewidth":.7,
    "svg.fonttype":"none", "pdf.fonttype":42, "ps.fonttype":42,
    "axes.spines.top":False, "axes.spines.right":False,
    "text.color":C["ink"], "axes.labelcolor":C["ink"]})

def fmt3(v):
    return f"{v:.3f}".replace("-", MINUS)

def fmtd(v):
    return f"{v:+.3f}".replace("-", MINUS)

def canvas(height):
    return plt.figure(figsize=(W,height/25.4),facecolor="white")

def panel(fig, rect, label, title):
    ax=fig.add_axes(rect)
    ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis("off")
    ax.text(0,1.035,label,fontsize=9,fontweight="bold",transform=ax.transAxes,va="bottom")
    ax.text(.045,1.035,title,fontsize=8,fontweight="bold",transform=ax.transAxes,va="bottom")
    return ax

def titled_axes(fig, rect, label, title):
    ax=fig.add_axes(rect)
    ax.text(0,1.035,label,fontsize=9,fontweight="bold",transform=ax.transAxes,va="bottom")
    ax.text(.085,1.035,title,fontsize=8,fontweight="bold",transform=ax.transAxes,va="bottom")
    return ax

def box(ax,x,y,w,h,text,kind="gray",fs=7.5):
    p=FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0.006,rounding_size=0.012",
        linewidth=.8,edgecolor=C[kind],facecolor=C[kind+"bg"])
    ax.add_patch(p)
    ax.text(x+w/2,y+h/2,text,ha="center",va="center",fontsize=fs,linespacing=1.28)
    return (x,y,w,h)

def arrow(ax,points,color="gray",dash=False):
    for a,b in zip(points[:-2],points[1:-1]):
        ax.plot([a[0],b[0]],[a[1],b[1]],color=C[color],lw=.85,
                ls=(0,(3,2)) if dash else "-",zorder=1)
    ax.add_patch(FancyArrowPatch(points[-2],points[-1],arrowstyle="-|>",
        mutation_scale=7,linewidth=.85,color=C[color],
        linestyle=(0,(3,2)) if dash else "-",shrinkA=0,shrinkB=1,zorder=1))

def save(fig,name,axes,labels,rows=None,cols=None,require_panel_labels=True):
    fig.canvas.draw()
    require_matplotlib_panel_alignment(fig,axes=axes,panel_ids=labels,
       row_groups=rows or [],column_groups=cols or [],
       require_panel_labels=require_panel_labels,
       tolerance_pt=1.5,gutter_tolerance_pt=1.5,strict=True,
       json_out=str(QA/(name+".alignment.json")))
    fig.savefig(OUT/(name+".pdf"))
    fig.savefig(OUT/(name+".svg"))
    fig.savefig(FIGURES/(name+".png"),dpi=600)
    plt.close(fig)

def csvout(name,header,rows):
    with (DATA/(name+".csv")).open("w",newline="") as f:
        w=csv.writer(f);w.writerow(header);w.writerows(rows)

def f1():
    broad=CANDIDATES["schema-aware depth-200 union"]["mean_size"]
    ce_pool=CANDIDATES["CE depth-50 union"]["mean_size"]
    n_tasks=STAGE1["record_count"]
    fig=canvas(163)
    a=panel(fig,[.035,.84,.93,.125],"a","Observed inputs after tool selection")
    box(a,.015,.07,.29,.78,"Request q\nBook the same route\nand seat as last time.","blue")
    box(a,.355,.07,.29,.78,"Selected schema S\nbook_trip: origin,\ndestination, seat_class","gold")
    box(a,.695,.07,.29,.78,"Memory bank M\n19,661 historical\nconversations","gray")
    b=panel(fig,[.035,.345,.93,.43],"b","Candidate access and frozen scoring")
    box(b,.24,.81,.52,.16,"BM25-Q · Dense-Q · Hybrid-Q (q only)\nSchema-Hybrid (q + tool name + description)\nFour lists over the same fixed bank M","blue",6.9)
    box(b,.015,.555,.42,.14,f"Broad union: top-200 per list\nmean {broad:.1f} candidates (n={n_tasks})","gray")
    box(b,.565,.555,.42,.14,f"CE pool: top-50 per list\nmean {ce_pool:.1f} candidates (n={n_tasks})","gray")
    arrow(b,[(.35,.81),(.35,.78),(.225,.78),(.225,.695)],"blue")
    arrow(b,[(.65,.81),(.65,.78),(.775,.78),(.775,.695)],"blue")
    box(b,.015,.285,.42,.195,"12 lightweight coordinates\nq / tool / field similarities\n+ request / tool reciprocal ranks\nInputs: q, S, M; all broad candidates","green",7.2)
    box(b,.565,.285,.42,.195,"6 CE coordinates: q–m, (q+S)–m\nscore / reciprocal rank / mask\nOne checkpoint; one shared CE pool\nOutside pool: floor / 0 / 0","blue",7.0)
    arrow(b,[(.225,.555),(.225,.48)])
    arrow(b,[(.775,.555),(.775,.48)])
    arrow(b,[(.435,.625),(.50,.625),(.50,.515),(.64,.515),(.64,.48)])
    box(b,.015,.025,.275,.135,"Concatenate\n18 stored coordinates","gray",7.2)
    box(b,.365,.025,.275,.135,"Frozen linear score\n"+r"$s=\mathbf{w}^{\mathsf{T}}(\mathbf{z}\oslash\sigma_\Delta)$","purple",8)
    box(b,.715,.025,.27,.135,"Sort: top-k text + IDs\nk=5 in primary evaluation","green",7.0)
    arrow(b,[(.225,.285),(.225,.16)],"green")
    arrow(b,[(.775,.285),(.775,.225),(.1525,.225),(.1525,.16)],"blue")
    arrow(b,[(.29,.0925),(.365,.0925)])
    arrow(b,[(.64,.0925),(.715,.0925)])
    c=panel(fig,[.035,.055,.93,.225],"c","Fold-local training only")
    box(c,.015,.665,.275,.25,"Training tasks\n(q, S, G)","purple")
    box(c,.365,.665,.275,.25,"Broad candidates + gold\n$P{=}G$; $N{=}C^{\\mathrm{tr}}{\\setminus}G$","purple")
    box(c,.715,.665,.27,.25,"Materialize all\n18 raw coordinates","purple")
    box(c,.715,.22,.27,.25,"Within-query differences\n$\\Delta z$ and $-\\Delta z$","purple")
    box(c,.365,.22,.275,.25,"Fit $\\sigma_\\Delta$; scale rows\nFit weighted logistic model","purple",7.2)
    box(c,.015,.22,.275,.25,"Freeze $\\sigma_\\Delta$ and $\\mathbf{w}$\nUse in panel b","purple")
    arrow(c,[(.29,.79),(.365,.79)],"purple")
    arrow(c,[(.64,.79),(.715,.79)],"purple")
    arrow(c,[(.85,.665),(.85,.47)],"purple")
    arrow(c,[(.715,.345),(.64,.345)],"purple")
    arrow(c,[(.365,.345),(.29,.345)],"purple")
    c.text(.5,.04,"Equal total loss mass per query; no reader or metric feedback.",
           ha="center",fontsize=7)
    # Dedicated outer routing lane transmits parameters, never gold labels.
    pts=[(.049,.1326),(.012,.1326),(.012,.326),(.502,.326),(.502,.3557)]
    for p,q in zip(pts[:-2],pts[1:-1]):
        fig.add_artist(Line2D([p[0],q[0]],[p[1],q[1]],transform=fig.transFigure,
            color=C["purple"],lw=.9,ls=(0,(3,2))))
    fig.add_artist(FancyArrowPatch(pts[-2],pts[-1],transform=fig.transFigure,
        arrowstyle="-|>",mutation_scale=7,color=C["purple"],lw=.9,linestyle=(0,(3,2))))
    save(fig,"figure1_overview",[a,b,c],["a","b","c"],cols=[["a","b","c"]])
    csvout("figure1_pools",["pool","mean_size","tasks"],
           [["broad depth-200 union",broad,n_tasks],["CE depth-50 union",ce_pool,n_tasks]])

def f2():
    # Figure contract: one continuous evidence chain shows how an audited task
    # cohort becomes leakage-safe OOF rankings and then component-aware paired
    # inference. Reader-only exclusions belong to Figure 5, not this workflow.
    fig=canvas(148)
    ax=fig.add_axes([.035,.025,.93,.95])
    ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis("off")

    ax.text(.015,.998,"Audited inputs",fontsize=8.2,fontweight="bold",va="top")
    box(ax,.015,.870,.400,.080,
        "400 released tasks\n391 retrieval tasks\n9 lack gold conversation IDs",
        "blue",6.20)
    box(ax,.585,.870,.400,.080,
        "Fixed searchable bank M\n19,661 conversations\nAvailable in every training and test fold",
        "green",6.10)

    # One protocol selector replaces four disconnected cards. The rows encode
    # alternative split rules, all feeding the same fold-local procedure.
    px,py,pw,ph=.015,.620,.930,.235
    outer=FancyBboxPatch((px,py),pw,ph,boxstyle="round,pad=0.006,rounding_size=0.012",
        linewidth=.85,edgecolor=C["blue"],facecolor="#F8FBFD")
    ax.add_patch(outer)
    ax.text(px+.018,py+ph-.021,
        "Choose one validation split; run the complete pipeline independently",
        fontsize=7.25,fontweight="bold",color=C["blue"],va="top")
    ax.text(px+.018,py+ph-.057,"Protocol",fontsize=6.05,fontweight="bold",color=C["gray"])
    ax.text(px+.285,py+ph-.057,"Training/test separation",fontsize=6.05,fontweight="bold",color=C["gray"])
    ax.text(px+.800,py+ph-.057,"OOF output",fontsize=6.05,fontweight="bold",color=C["gray"])
    ax.plot([px+.265,px+.265],[py+.010,py+ph-.045],color="#D5DADF",lw=.6)
    ax.plot([px+.780,px+.780],[py+.010,py+ph-.045],color="#D5DADF",lw=.6)
    rows=[
        ("Stratified five-fold","L1–L4 strata; seed 20260730","391 · primary"),
        ("Unseen-tool five-fold","Group by selected tool name","391 tasks"),
        ("Shared-source five-fold","Group 366 labelled-source components; bank stays searchable","391 tasks"),
        ("Leave-source-out (3 holds)","Exclude tasks touching held-out corpus; bank stays searchable","383 tasks")]
    y0=py+ph-.086
    for i,(name,rule,n) in enumerate(rows):
        yy=y0-i*.0315
        if i:
            ax.plot([px+.012,px+pw-.012],[yy+.0158,yy+.0158],color="#E1E5E8",lw=.5)
        ax.add_patch(plt.Rectangle((px+.008,yy-.010),.006,.020,color=C["green"] if i==3 else C["blue"],lw=0))
        ax.text(px+.020,yy,name,fontsize=5.75,fontweight="bold",va="center")
        ax.text(px+.285,yy,rule,fontsize=5.35,va="center")
        ax.text(px+.800,yy,n,fontsize=5.60,va="center")
    arrow(ax,[(.215,.870),(.215,.862),(.480,.862),(.480,.855)],"blue")
    arrow(ax,[(.480,.620),(.480,.595)],"blue")

    # The shared fold procedure is one connected unit. Training labels may
    # augment training candidates; the fixed bank feeds the unaugmented test
    # candidate pool; frozen parameters cross from the training to test lane.
    fx,fy,fw,fh=.015,.405,.930,.190
    fold=FancyBboxPatch((fx,fy),fw,fh,boxstyle="round,pad=0.006,rounding_size=0.012",
        linewidth=.8,edgecolor=C["gray"],facecolor="white")
    ax.add_patch(fold)
    ax.text(fx+.018,fy+fh-.016,"Repeat for every fold",fontsize=7.15,fontweight="bold",va="top")
    ax.text(fx+.020,fy+.111,"TRAIN",fontsize=5.95,fontweight="bold",color=C["purple"],va="center")
    box(ax,.105,.492,.170,.058,"Training tasks\n(q, S, G)","purple",5.95)
    box(ax,.335,.492,.275,.058,"Cᵗʳ = C²⁰⁰ ∪ G\nMirrored within-query differences","purple",5.60)
    box(ax,.670,.492,.220,.058,"Fit σΔ and w\nFreeze fold model","purple",5.90)
    arrow(ax,[(.275,.521),(.335,.521)],"purple")
    arrow(ax,[(.610,.521),(.670,.521)],"purple")

    ax.text(fx+.020,fy+.038,"TEST",fontsize=5.95,fontweight="bold",color=C["blue"],va="center")
    box(ax,.105,.419,.170,.058,"Test tasks\n(q, S)","blue",5.95)
    box(ax,.335,.419,.275,.058,"Original C²⁰⁰ from M\nNo gold insertion","blue",5.65)
    box(ax,.670,.419,.220,.058,"Frozen scoring\nOOF top-k ranking","blue",5.90)
    arrow(ax,[(.275,.448),(.335,.448)],"blue")
    arrow(ax,[(.610,.448),(.670,.448)],"blue")
    arrow(ax,[(.780,.492),(.780,.477)],"purple",True)
    # The fixed bank is an input to candidate construction, not another cohort.
    arrow(ax,[(.785,.870),(.785,.862),(.970,.862),(.970,.398),(.4725,.398),(.4725,.419)],"green",True)

    # Held-out annotations join only after ranking. From here onward, every
    # object belongs to the paired inferential chain rather than model fitting.
    ax.text(.015,.370,"Evaluation and inference",fontsize=7.8,fontweight="bold",va="top")
    box(ax,.105,.286,.300,.058,
        "Held-out gold labels\nUnavailable to fitting and scoring","gold",5.85)
    box(ax,.595,.286,.300,.058,"OOF top-k ranking","blue",6.15)
    box(ax,.275,.196,.450,.064,
        "Per-task SCAR-Pair $-$ comparator differences\nRecall@5 · Complete@5 · nDCG@5","gray",5.90)
    box(ax,.075,.070,.850,.092,
        "Group by shared-source components (366; 359 for leave-source-out)\n"
        "10,000 bootstrap resamples → 95% interval     50,000 joint sign flips + plus-one → p\n"
        "Holm adjustment within each comparator; inference conditions on fixed OOF predictions (no refitting)\n"
        "Leave-source-out also reports pooled-task and equal-corpus macro means",
        "gray",5.35)
    arrow(ax,[(.780,.419),(.745,.344)],"blue")
    arrow(ax,[(.255,.286),(.255,.273),(.425,.273),(.425,.260)],"gold")
    arrow(ax,[(.745,.286),(.745,.273),(.575,.273),(.575,.260)],"blue")
    arrow(ax,[(.500,.196),(.500,.162)],"gray")
    ax.text(.500,.035,
        "Each protocol produces its own OOF predictions; estimates are never pooled across protocols.",
        ha="center",fontsize=5.85,fontweight="bold",color=C["blue"])

    save(fig,"figure2_protocol",[ax],["workflow"],
         require_panel_labels=False)

def f3():
    protocols=[("stratified","Stratified"),
               ("unseen_tool","Unseen tool"),
               ("shared_source","Shared source"),
               ("leave_source_out","Leave source out")]
    comparators=[("Query-Pair-strict","Query-Pair",C["gold"],"^"),
                 ("Query-Fuse-strict","Query-Fuse",MC[0],"o"),
                 ("CE-Calibrated-Broad","CE-Calibrated-Broad",MC[1],"s"),
                 ("SCAR-Fuse","SCAR-Fuse",MC[2],"D")]
    fig=canvas(190)
    X0,X1,AXW=.210,.660,.280
    def forest(rect,metric,letter,title):
        ax=titled_axes(fig,rect,letter,title)
        rows=[];headers=[];y=0.0
        for pkey,pname in protocols:
            headers.append((y,pname))
            y-=1.0
            for cname,label,color,mk in comparators:
                r=diff_row(pkey,cname,metric)
                rows.append((y,label,color,mk,r["difference"],*r["ci95"]))
                y-=1.0
            y-=0.7
        ax.axvline(0,color="#9AA3AA",lw=.8,ls="--",zorder=0)
        for yy,cname,color,mk,d,lo,hi in rows:
            significant = lo>0 or hi<0
            ax.plot([lo,hi],[yy,yy],color=color,lw=1.3,zorder=2,solid_capstyle="round")
            for cap in (lo,hi):
                ax.plot([cap,cap],[yy-.16,yy+.16],color=color,lw=1.0,zorder=2)
            ax.plot(d,yy,mk,ms=4.6,color=color,mew=1.1,
                    mfc=color if significant else "white",zorder=3)
            label_x = hi + .004
            ax.text(label_x,yy,fmt3(d),ha="left",
                    va="center",fontsize=6.2,zorder=4,color=C["ink"])
        for yy,pname in headers:
            ax.text(-.04,yy,pname,transform=ax.get_yaxis_transform(),ha="right",
                    fontsize=7.1,fontweight="bold",va="center",clip_on=False)
        ax.set(xlim=(-.056,.132),ylim=(y+.4,.75),xticks=[-.04,0,.04,.08,.12])
        if letter=="a":
            ax.set_yticks([r[0] for r in rows])
            ax.set_yticklabels([r[1] for r in rows],fontsize=6.6)
        else:
            ax.set_yticks([])
        ax.tick_params(axis="y",length=0)
        ax.tick_params(axis="x",labelsize=6.8)
        ax.spines["left"].set_visible(False)
        ax.set_xlabel("SCAR-Pair $-$ comparator at $k=5$",fontsize=7.5)
        return ax
    a=forest([X0,.575,AXW,.365],"recall","a","Recall@5 differences")
    b=forest([X1,.575,AXW,.365],"ndcg","b","nDCG@5 differences")
    fig.text(.5,.496,"Whiskers: 95% shared-source-component bootstrap intervals; "
             "filled markers exclude zero.",ha="center",fontsize=6.8)
    fig.text(.5,.456,"Pooled and equal-corpus estimates",ha="center",
             fontsize=8,fontweight="bold")
    display=[("Query-Pair-strict","Query-Pair",C["gold"]),
             ("Query-Fuse-strict","Query-Fuse",MC[0]),
             ("CE-Calibrated-Broad","CE-Calibrated-\nBroad",MC[1]),
             ("SCAR-Fuse","SCAR-Fuse",MC[2]),
             ("SCAR-Pair","SCAR-Pair",MC[3])]
    axes=[a,b]
    for j,(mkey,letter,title) in enumerate([("recall","c","LSO Recall@5"),("ndcg","d","LSO nDCG@5")]):
        ax=titled_axes(fig,[X0+j*(X1-X0),.115,AXW,.280],letter,title)
        for i,(m,label,color) in enumerate(display):
            yy=4-i
            v=AGG[("leave_source_out",m)][mkey];z=MACRO[m][mkey]
            ax.plot([z,v],[yy,yy],color="#B9BEC3",lw=1,zorder=1)
            ax.plot(v,yy,"o",ms=4.5,color=color,zorder=3)
            ax.plot(z,yy,"o",ms=4.5,color=color,mfc="white",zorder=3)
            ax.text(z,yy-.30,fmt3(z),ha="center",fontsize=6.6)
            ax.text(v,yy+.22,fmt3(v),ha="center",fontsize=6.6)
        ax.set(xlim=(.22,.47),ylim=(-.55,4.55),xticks=[.25,.30,.35,.40,.45],
               yticks=[4,3,2,1,0],yticklabels=[d[1] for d in display] if j==0 else [])
        ax.tick_params(axis="y",length=0)
        ax.tick_params(axis="x",labelsize=6.8)
        ax.set_xlabel("")
        axes.append(ax)
    handles=[Line2D([],[],marker="o",linestyle="",color=C["gray"],label="Pooled (383 tasks)"),
             Line2D([],[],marker="o",linestyle="",color=C["gray"],mfc="white",
                    label="Macro (3 sources equally weighted)")]
    fig.legend(handles=handles,loc="lower center",bbox_to_anchor=(.5,.008),ncol=2,
               frameon=False,fontsize=7)
    save(fig,"figure3_retrieval_transfer",axes,["a","b","c","d"],
         rows=[["a","b"],["c","d"]],cols=[["a","c"],["b","d"]])
    csvout("figure3_forest",
           ["protocol","comparator","metric","difference","ci95_lo","ci95_hi","tasks","components"],
           [[p,c,m,*([diff_row(p,c,m)[k] for k in ("difference",)]),
             *diff_row(p,c,m)["ci95"],diff_row(p,c,m)["tasks"],diff_row(p,c,m)["components"]]
            for p,_ in protocols for c,_,_,_ in comparators for m in ("recall","ndcg")])
    csvout("figure3_averaging",["method","pooled_recall","macro_recall","pooled_ndcg","macro_ndcg"],
           [[m,AGG[("leave_source_out",m)]["recall"],MACRO[m]["recall"],
             AGG[("leave_source_out",m)]["ndcg"],MACRO[m]["ndcg"]] for m,_,_ in display])

def f4():
    fig=canvas(120)
    a=fig.add_axes([.30,.56,.62,.24]);b=fig.add_axes([.30,.20,.62,.19])
    for ax,letter,title in [(a,"a","Candidate access"),(b,"b","Schema CE scoring")]:
        ax.text(0,1.30,letter,transform=ax.transAxes,fontsize=9,fontweight="bold")
        ax.text(.06,1.30,title,transform=ax.transAxes,fontsize=8,fontweight="bold")
        ax.axvline(0,color="#9AA3AA",lw=.8,ls="--",zorder=0)
        ax.spines["left"].set_visible(False)
    a.text(.5,1.13,"Hold Query-Fuse features fixed; change only the candidate pool",
           ha="center",transform=a.transAxes,fontsize=6.8)
    b.text(.5,1.13,"Hold the broad pool and calibrator fixed; add schema CE features",
           ha="center",transform=b.transAxes,fontsize=6.8)
    strat=lambda m: AGG[("stratified",m)]
    strict=strat("Query-Fuse-strict");schema_pool=strat("Query-Fuse-schema-pool")
    ce_query=strat("CE-Query-Calibrated-Broad");ce_dual=strat("CE-Calibrated-Broad")
    rows=[("Candidate source recall",
           CANDIDATES["request-only depth-200 union"]["recall"],
           CANDIDATES["schema-aware depth-200 union"]["recall"],None),
          ("Final Recall@5",strict["recall"],schema_pool["recall"],
           stat_row("stratified","Query-Fuse-schema-pool","Query-Fuse-strict","recall")),
          ("Final nDCG@5",strict["ndcg"],schema_pool["ndcg"],
           stat_row("stratified","Query-Fuse-schema-pool","Query-Fuse-strict","ndcg"))]
    ce_rows=[(1,"Recall@5",ce_query["recall"],ce_dual["recall"],
              stat_row("stratified","CE-Calibrated-Broad","CE-Query-Calibrated-Broad","recall")),
             (0,"nDCG@5",ce_query["ndcg"],ce_dual["ndcg"],
              stat_row("stratified","CE-Calibrated-Broad","CE-Query-Calibrated-Broad","ndcg"))]
    for y,(label,x,z,stat) in zip([2,1,0],rows):
        d=z-x
        if stat is None:
            lo=hi=d
            a.plot(d,y,"s",mfc=C["gold"],mec=C["gold"],ms=4.8,zorder=3)
            suffix="descriptive"
        else:
            lo,hi=stat["ci95"]
            a.plot([lo,hi],[y,y],color=C["gold"],lw=1.3,solid_capstyle="round")
            a.plot([lo,lo],[y-.10,y+.10],color=C["gold"],lw=1)
            a.plot([hi,hi],[y-.10,y+.10],color=C["gold"],lw=1)
            a.plot(d,y,"s",mfc=C["gold"] if lo>0 or hi<0 else "white",
                   mec=C["gold"],ms=4.8,zorder=3)
            suffix="95% CI"
        a.text(.083,y+.10,f"{fmt3(x)}→{fmt3(z)}",fontsize=6.4,va="center")
        a.text(.083,y-.16,f"Δ {fmtd(d)}; {suffix}",fontsize=5.9,va="center")
    a.set(xlim=(-.015,.14),ylim=(-.45,2.45),xticks=[0,.04,.08,.12],
          yticks=[2,1,0],yticklabels=[r[0] for r in rows])
    for y,label,x,z,stat in ce_rows:
        d=z-x;lo,hi=stat["ci95"]
        b.plot([lo,hi],[y,y],color=C["blue"],lw=1.3,solid_capstyle="round")
        b.plot([lo,lo],[y-.10,y+.10],color=C["blue"],lw=1)
        b.plot([hi,hi],[y-.10,y+.10],color=C["blue"],lw=1)
        b.plot(d,y,"s",mfc=C["blue"] if lo>0 or hi<0 else "white",
               mec=C["blue"],ms=4.8,zorder=3)
        b.text(.083,y+.10,f"{fmt3(x)}→{fmt3(z)}",fontsize=6.4,va="center")
        b.text(.083,y-.16,f"Δ {fmtd(d)}; 95% CI",fontsize=5.9,va="center")
    b.set(xlim=(-.015,.14),ylim=(-.45,1.45),xticks=[0,.04,.08,.12],
          yticks=[1,0],yticklabels=[r[1] for r in ce_rows])
    for ax in (a,b):
        ax.tick_params(axis="y",length=0,labelsize=6.7)
        ax.tick_params(axis="x",labelsize=6.7)
        ax.set_xlabel("Schema condition − query-only",fontsize=7)
    fig.text(.5,.045,"Whiskers: 95% component-bootstrap intervals; candidate access is descriptive.",
             ha="center",fontsize=6.6)
    save(fig,"figure4_schema_controls",[a,b],["a","b"],cols=[["a","b"]])
    def stat_cells(stat):
        return ["", "", ""] if stat is None else [stat["ci95"][0], stat["ci95"][1], stat["component_p_holm"]]
    csvout("figure4_controls",
           ["comparison","metric","query_only","schema_condition","ci95_lo","ci95_hi","holm_p"],
           [["candidate_access",m,x,z,*stat_cells(stat)] for m,x,z,stat in rows]
           + [["ce_scoring",m,x,z,*stat_cells(stat)] for _,m,x,z,stat in ce_rows])

def f5():
    fig=canvas(139)
    a=panel(fig,[.04,.66,.92,.29],"a","One frozen reader; controlled context")
    box(a,.015,.665,.27,.24,"Observed request q\nFull selected schema S","gold",7.5)
    box(a,.015,.25,.27,.24,"Context: none / retrieved /\nOracle-Gold sources","gray",7.0)
    box(a,.365,.665,.27,.24,"Fixed context builder\nFrozen reader","blue",7.4)
    box(a,.735,.665,.25,.24,"Predicted JSON","gray",7.5)
    box(a,.735,.25,.25,.24,"Exact match\n+ schema validity","gray",7.3)
    a.text(.15,.06,"Gold source IDs\nOracle condition only",ha="center",va="center",fontsize=6.8)
    a.text(.50,.075,"Gold arguments\nEvaluation only",ha="center",va="center",fontsize=6.9)
    arrow(a,[(.285,.785),(.365,.785)],"gold")
    arrow(a,[(.285,.37),(.32,.37),(.32,.70),(.365,.70)])
    arrow(a,[(.635,.785),(.735,.785)])
    arrow(a,[(.86,.665),(.86,.49)])
    arrow(a,[(.15,.14),(.15,.25)],"gray",True)
    arrow(a,[(.635,.075),(.86,.075),(.86,.25)],"gray",True)
    # Selected schema is also required by the validator; a separate labelled lane.
    arrow(a,[(.24,.665),(.24,.56),(.99,.56),(.99,.37),(.985,.37)],"gold")
    a.text(.60,.59,"S for validation",ha="center",fontsize=6.6,color=C["gold"])
    source=["No-memory","Query-Fuse-strict","CE-Calibrated-Broad","SCAR-Fuse",
            "SCAR-Pair","Oracle-Gold","Hybrid-Q","CE-Calibrated"]
    labels=["No memory","Query-Fuse","CE-Calibrated-\nBroad","SCAR-Fuse",
            "SCAR-Pair","Oracle-Gold","Hybrid-Q","CE-Calibrated"]
    colors=["#9AA0A6",MC[0],MC[1],MC[2],MC[3],"#80608F","#56B4E9","#E69F00"]
    marks=["o","o","s","D","^","h","v","X"]
    raw=READER_CONSISTENT
    axes=[]
    for j,(key,title,xmax,ticks) in enumerate([
       ("memory_argument_em","Arg-EM",.21,[0,.05,.10,.15,.20]),
       ("full_call_em","Full-call EM",.13,[0,.04,.08,.12]),
       ("schema_validity","Schema validity",1.05,[0,.25,.50,.75,1])]):
        ax=fig.add_axes([.265+j*.247,.13,.205,.36]);axes.append(ax)
        ax.text(0,1.11,["b","c","d"][j],transform=ax.transAxes,fontsize=9,fontweight="bold")
        ax.text(.13,1.11,title,transform=ax.transAxes,fontsize=7.2,fontweight="bold",va="baseline")
        for i,name in enumerate(source):
            v=raw[name][key];y=7-i
            ax.plot(v,y,marks[i],color=colors[i],mfc=colors[i] if i in [3,4] else "white",ms=4.5)
            ax.text(v,y+.48,fmt3(v),ha="right" if v>.9 else "center",fontsize=7)
        ax.set(xlim=(0,xmax),ylim=(-.55,7.65),xticks=ticks,yticks=np.arange(8),
           yticklabels=list(reversed(labels)) if j==0 else [])
        ax.tick_params(axis="y",length=0)
        ax.tick_params(axis="x",labelsize=6.4)
        ax.spines["left"].set_visible(False)
        ax.set_xlabel("Proportion",fontsize=7)
    fig.text(.5,.605,"385 gold-schema-consistent tasks; point estimates only",ha="center",fontsize=7.5)
    fig.text(.5,.045,"No memory keeps the highest schema validity; Oracle-Gold has the highest exact-match estimates.",
             ha="center",fontsize=6.9)
    fig.text(.5,.02,"All readers receive S. Oracle-Gold is a source-context control, not a perfect-reader ceiling.",
             ha="center",fontsize=6.9)
    save(fig,"figure5_reader_boundary",[a,*axes],["a","b","c","d"],rows=[["b","c","d"]])
    csvout("figure5_reader",["condition","json_validity","schema_validity","argument_em","memory_call_em","full_call_em"],
           [[n,raw[n]["json_validity"],raw[n]["schema_validity"],raw[n]["memory_argument_em"],
             raw[n]["memory_call_em"],raw[n]["full_call_em"]] for n in source])

if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument(
        "--fig", nargs="*", type=int, default=[3, 4, 5],
        help=("Figure numbers to rebuild. The default is 3 4 5; Figures 1 and 2 "
              "are conceptual schematics."),
    )
    args=parser.parse_args()
    for n in args.fig:
        globals()[f"f{n}"]()
        print(f"Saved figure {n}")
