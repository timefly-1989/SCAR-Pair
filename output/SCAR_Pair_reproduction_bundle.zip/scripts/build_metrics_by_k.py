"""Regenerate figures/metrics_by_k.pdf from authoritative reproduction data.

Every point is loaded from reproduction/output/retrieval_report.json
(aggregates_by_k, stratified protocol), the same values published in
tables/generated/cutoffs.tex. The k=5 cells are asserted against the
published table before drawing. No uncertainty is drawn because the
per-cutoff bootstrap was not part of the reported analysis.
"""

from __future__ import annotations

import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from audit_panel_alignment import require_matplotlib_panel_alignment

ROOT = Path(__file__).resolve().parents[1]
FIG_DIR = ROOT / "figures"
VECTOR_DIR = FIG_DIR / "vector"
DATA_DIR = ROOT / "reproduction" / "figure_data"
QA_DIR = ROOT / "build" / "figure_qa"
REPORT = ROOT / "reproduction" / "output" / "retrieval_report.json"
OUT_BASENAME = "metrics_by_k"

K = [1, 3, 5, 10]
METHODS = ["Query-Fuse-strict", "CE-Calibrated-Broad", "SCAR-Fuse", "SCAR-Pair"]
LABELS = {
    "Query-Fuse-strict": "Query-Fuse (strict)",
    "CE-Calibrated-Broad": "CE-Calibrated-Broad",
    "SCAR-Fuse": "SCAR-Fuse (pointwise)",
    "SCAR-Pair": "SCAR-Pair",
}
COLORS = {
    "Query-Fuse-strict": "#687782",
    "CE-Calibrated-Broad": "#D55E00",
    "SCAR-Fuse": "#0072B2",
    "SCAR-Pair": "#009E73",
}
MARKERS = {
    "Query-Fuse-strict": "o",
    "CE-Calibrated-Broad": "s",
    "SCAR-Fuse": "D",
    "SCAR-Pair": "^",
}
# Published k=5 cells (tables/generated/cutoffs.tex); asserted before drawing.
K5_EXPECTED = {
    "Query-Fuse-strict": (0.388, 0.316),
    "CE-Calibrated-Broad": (0.419, 0.334),
    "SCAR-Fuse": (0.436, 0.353),
    "SCAR-Pair": (0.450, 0.365),
}


def load() -> dict:
    payload = json.loads(REPORT.read_text(encoding="utf-8"))["aggregates_by_k"]
    series = {m: {"recall": [], "ndcg": []} for m in METHODS}
    for m in METHODS:
        for k in K:
            row = next(
                r
                for r in payload
                if r["protocol"] == "stratified" and r["method"] == m and r["k"] == k
            )
            series[m]["recall"].append(row["recall"])
            series[m]["ndcg"].append(row["ndcg"])
        assert (
            round(series[m]["recall"][2], 3),
            round(series[m]["ndcg"][2], 3),
        ) == K5_EXPECTED[m], m
    return series


def main() -> None:
    VECTOR_DIR.mkdir(parents=True, exist_ok=True)
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    QA_DIR.mkdir(parents=True, exist_ok=True)
    series = load()
    plt.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["DejaVu Sans"],
            "font.size": 8,
            "axes.labelsize": 8,
            "xtick.labelsize": 7,
            "ytick.labelsize": 7,
            "legend.fontsize": 7,
            "axes.linewidth": 0.7,
            "pdf.fonttype": 42,
            "svg.fonttype": "none",
            "axes.spines.top": False,
            "axes.spines.right": False,
            "savefig.facecolor": "white",
        }
    )
    fig, axes = plt.subplots(1, 2, figsize=(136 / 25.4, 62 / 25.4))
    fig.subplots_adjust(left=0.09, right=0.985, bottom=0.30, top=0.90, wspace=0.32)
    for ax, metric, title in zip(axes, ("recall", "ndcg"), ("Recall@$k$", "nDCG@$k$")):
        for m in METHODS:
            ax.plot(
                K,
                series[m][metric],
                marker=MARKERS[m],
                ms=3.6,
                lw=1.1,
                color=COLORS[m],
                label=LABELS[m],
            )
        ax.set(xticks=K, xlabel="Cut-off $k$", ylabel=title, xlim=(0.5, 10.5))
        ax.set_ylim(0.20, 0.56)
        ax.grid(axis="y", color="#EDF0F2", lw=0.6, zorder=0)
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(
        handles,
        labels,
        loc="lower center",
        bbox_to_anchor=(0.5, 0.015),
        ncol=2,
        frameon=False,
        borderpad=0.1,
        labelspacing=0.35,
        columnspacing=1.2,
        handlelength=2.0,
    )
    fig.canvas.draw()
    require_matplotlib_panel_alignment(
        fig,
        json_out=str(QA_DIR / (OUT_BASENAME + ".alignment.json")),
        overlay_svg=str(QA_DIR / (OUT_BASENAME + ".alignment.svg")),
        tolerance_pt=1.5,
        gutter_tolerance_pt=1.5,
        strict=True,
    )
    fig.savefig(FIG_DIR / (OUT_BASENAME + ".pdf"))
    fig.savefig(VECTOR_DIR / (OUT_BASENAME + ".svg"))
    with (DATA_DIR / "metrics_by_k.csv").open("w", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(["method", "k", "recall", "ndcg"])
        for m in METHODS:
            for i, k in enumerate(K):
                writer.writerow([m, k, series[m]["recall"][i], series[m]["ndcg"][i]])
    print("Wrote metrics_by_k.pdf/.svg and metrics_by_k.csv from retrieval_report.json")


if __name__ == "__main__":
    main()
