#!/usr/bin/env python3
"""Cross-check manuscript claims, generated tables, and figure source data.

This audit intentionally checks only values backed by the public reproduction
artifacts. It does not treat rounded manuscript cells as an experimental source.
"""

from __future__ import annotations

import csv
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "reproduction" / "output"


def read_json(name: str):
    return json.loads((OUT / name).read_text(encoding="utf-8"))


def close(left: float, right: float, tol: float = 1e-12) -> None:
    if abs(left - right) > tol:
        raise AssertionError(f"numeric mismatch: {left} != {right}")


def csv_rows(name: str) -> list[dict[str, str]]:
    path = ROOT / "reproduction" / "figure_data" / name
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def main() -> None:
    checks: list[str] = []
    manuscript = (ROOT / "main.tex").read_text(encoding="utf-8")
    supplement = (ROOT / "supplementary.tex").read_text(encoding="utf-8")

    validation = read_json("publication_validation_report.json")
    assert validation["status"] == "passed"
    checks.append("publication artifact integrity report passes")

    stage1 = read_json("stage1_report.json")
    audit = stage1["data_audit"]
    assert (audit["released_tasks"], audit["evidence_tasks"], audit["memory_documents"]) == (400, 391, 19661)
    assert len(audit["empty_source_task_ids"]) == 9
    checks.append("dataset counts and exclusions match the stage-1 audit")

    retrieval = read_json("retrieval_report.json")
    aggregates = {(row["protocol"], row["method"]): row for row in retrieval["aggregates"]}
    expected_primary = {
        "Query-Fuse-strict": (0.388, 0.363, 0.316),
        "SCAR-Fuse": (0.436, 0.414, 0.353),
        "SCAR-Pair": (0.450, 0.427, 0.365),
        "CE-Calibrated-Broad": (0.419, 0.396, 0.334),
    }
    primary_tex = (ROOT / "tables" / "generated" / "primary.tex").read_text(encoding="utf-8")
    for method, values in expected_primary.items():
        row = aggregates[("stratified", method)]
        observed = tuple(round(row[key], 3) for key in ("recall", "complete", "ndcg"))
        assert observed == values
        display = method.replace("-strict", " (strict)") if method == "Query-Fuse-strict" else method
        assert display in primary_tex and all(f"{value:.3f}" in primary_tex for value in values)
    checks.append("primary table agrees with per-task retrieval aggregates")

    stats = read_json("publication_statistics_report.json")
    assert stats["randomization"].startswith("50000 joint component sign flips")
    assert len(stats["results"]) == 84
    for row in stats["results"]:
        assert row["ci95"][0] <= row["difference"] <= row["ci95"][1]
        assert 0 <= row["component_p"] <= row["component_p_holm"] <= 1
    checks.append("all 84 inferential contrasts have valid component-level metadata and bounds")

    forest = csv_rows("figure3_forest.csv")
    indexed_stats = {
        (r["protocol"], r["right"], r["metric"]): r
        for r in stats["results"]
        if r["domain"] == "retrieval" and r["left"] == "SCAR-Pair"
    }
    for row in forest:
        source = indexed_stats[(row["protocol"], row["comparator"], row["metric"])]
        close(float(row["difference"]), source["difference"])
        close(float(row["ci95_lo"]), source["ci95"][0])
        close(float(row["ci95_hi"]), source["ci95"][1])
    checks.append("Figure 3 forest source data agree with component-level statistics")

    reader = {r["condition"]: r for r in read_json("publication_reader_report.json")["consistent"]}
    for row in csv_rows("figure5_reader.csv"):
        source = reader[row["condition"]]
        close(float(row["schema_validity"]), source["schema_validity"])
        close(float(row["argument_em"]), source["memory_argument_em"])
        close(float(row["full_call_em"]), source["full_call_em"])
    checks.append("Figure 5 source data agree with the corrected frozen-reader report")

    cutoff = {(r["method"], int(r["k"])): r for r in csv_rows("metrics_by_k.csv")}
    for row in retrieval["aggregates_by_k"]:
        if row["protocol"] == "stratified" and (row["method"], row["k"]) in cutoff:
            source = cutoff[(row["method"], row["k"])]
            close(float(source["recall"]), row["recall"])
            close(float(source["ndcg"]), row["ndcg"])
    checks.append("cutoff-curve source data agree with the retrieval report")

    required_claims = (
        "SCAR-Pair: Schema-Conditioned Memory Evidence Ranking",
        "Shuai Liu $^{1}$, Hui Li $^{1,*}$ and Jin Qian",
        "0.450 Recall@5",
        "0.365 nDCG@5",
        "component-level sign-randomization",
        "50{,}000 joint component-level sign flips",
        "lambda=1/(2|\\mathcal{D}_{tr}|C)",
        "no adjusted comparison is significant",
    )
    for claim in required_claims:
        assert claim in manuscript, claim
    forbidden = ("0.465 Recall@5", "mean 465.0", "not cluster-robust")
    for stale in forbidden:
        assert stale not in manuscript and stale not in supplement, stale
    checks.append("theory, headline results, and inferential wording are synchronized")

    for name in (
        "vector/figure1_overview.pdf",
        "vector/figure2_protocol.pdf",
        "vector/figure3_retrieval_transfer.pdf",
        "vector/figure4_schema_controls.pdf",
        "vector/figure5_reader_boundary.pdf",
    ):
        assert (ROOT / "figures" / name).is_file(), name
    checks.append("all five manuscript figure files are present")

    report = {
        "status": "passed",
        "authority": "reproduction/output/publication_* plus per-task predictions",
        "checks": checks,
        "submission_blockers_not_inferred": [
            "verified conflict-of-interest declaration",
            "persistent public archive DOI or reviewer-accessible URL",
            "author-confirmed complete AI-use history and disclosure wording",
        ],
    }
    report_path = ROOT / "build" / "manuscript_consistency.json"
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
