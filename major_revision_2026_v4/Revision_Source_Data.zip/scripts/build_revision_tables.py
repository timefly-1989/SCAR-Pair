#!/usr/bin/env python3
"""Generate revision tables only from per-task outputs and analysis reports."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "reproduction/output"
TABLES = ROOT / "tables/generated"


def load(name):
    return json.loads((OUT / name).read_text())


def fmt_p(p):
    return "$<0.001$" if p < .001 else f"{p:.3f}"


def fmt_ci(x):
    return f"[{x[0]:.3f}, {x[1]:.3f}]"


def fmt_delta(x):
    return "0.000" if abs(x) < .0005 else f"{x:.3f}"


def make_controls():
    controls = load("revision_controls_report.json")["aggregates"]
    controls = {r["method"]: r for r in controls if r["protocol"] == "stratified"}
    mismatch = load("revision_mismatch_report.json")["runs"]
    stats = load("revision_statistics_report.json")["results"]
    ndcg = {r["right"]: r for r in stats if r["domain"] == "retrieval"
            and r["protocol"] == "stratified" and r["left"] == "SCAR-Pair"
            and r["metric"] == "ndcg"}
    values = [("SCAR-Pair", controls["SCAR-Pair-refit"], None),
              ("Query-CE replay", controls["Query-CE-replay"], ndcg["Query-CE-replay"])]
    values.extend((f"Mismatch {r['permutation']}", r["aggregates"], ndcg[r["method"]])
                  for r in mismatch)
    values.append(("No-insertion refit", controls["No-insertion-refit"], ndcg["No-insertion-refit"]))
    lines = [r"\begin{table}[tbp]", r"\caption{Post-review stratified controls ($n=391$). $\Delta$ is SCAR-Pair minus each control in nDCG@5; intervals use 10,000 shared-source-component bootstrap resamples and $p_H$ uses 50,000 joint component sign flips with Holm adjustment over Recall, Complete, and nDCG within each comparison. The replay and five prespecified different-tool-schema permutations preserve the broad pool, 18 feature positions, and pairwise estimator; only the schema CE triplet changes. No-insertion refit skips zero-hit training tasks but retains all test tasks. These exploratory tests do not establish equivalence.}", r"\label{tab:revision_controls}", r"\centering\scriptsize", r"\setlength{\tabcolsep}{3pt}", r"\begin{tabular}{lrrrrr}", r"\toprule", r"Method & Recall@5 & nDCG@5 & $\Delta$nDCG & 95\% CI & $p_H$ \\", r"\midrule"]
    for name, a, s in values:
        if s is None:
            tail = "--- & --- & ---"
        else:
            tail = f"{fmt_delta(s['difference'])} & {fmt_ci(s['ci95'])} & {fmt_p(s['component_p_holm'])}"
        lines.append(f"{name} & {a['recall']:.3f} & {a['ndcg']:.3f} & {tail} " + r"\\")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    (TABLES / "revision_controls.tex").write_text("\n".join(lines) + "\n")


def make_sensitivity():
    a = {r["method"]: r for r in load("revision_sensitivity_report.json")["aggregates"]}
    baseline = {r["method"]: r for r in load("revision_controls_report.json")["aggregates"]
                if r["protocol"] == "stratified"}["SCAR-Pair-refit"]
    lines = [r"\begin{table}[tbp]", r"\caption{One-factor post-review sensitivity on the stratified folds ($n=391$); the original fixed setting is $C=1$, $\epsilon_u=10^{-6}$, $d_1=200$, $d_2=50$. $\lambda=1/(2|\mathcal D_{tr}|C)$, so $C$ and $\lambda$ are not independent knobs. The joint candidate-depth grid is reported separately in Table~S5. These point estimates were not used for model selection.}", r"\label{tab:revision_sensitivity}", r"\centering\small", r"\begin{tabular}{lrrr}", r"\toprule", r"Setting & Recall@5 & Complete@5 & nDCG@5 \\", r"\midrule"]
    for name, values in ((r"$C=0.1$, $\epsilon_u=10^{-6}$", a["C=0.1"]),
                         (r"$C=1$, $\epsilon_u=10^{-6}$ (fixed)", baseline),
                         (r"$C=10$, $\epsilon_u=10^{-6}$", a["C=10"]),
                         (r"$C=1$, $\epsilon_u=10^{-3}$", a["epsilon=1e-3"])):
        lines.append(f"{name} & {values['recall']:.3f} & {values['complete']:.3f} & {values['ndcg']:.3f} " + r"\\")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    (TABLES / "revision_sensitivity.tex").write_text("\n".join(lines) + "\n")


def make_no_insertion():
    a = {(r["protocol"], r["method"]): r for r in load("revision_controls_report.json")["aggregates"]
         if r["method"] in ("No-insertion-refit", "Query-Pair-no-insertion")}
    stats = {(r["protocol"], r["metric"]): r for r in load("revision_statistics_report.json")["results"]
             if r["domain"] == "retrieval" and r["left"] == "No-insertion-refit"
             and r["right"] == "Query-Pair-no-insertion"}
    lines = [r"\begin{table}[tbp]", r"\caption{Matched no-insertion refits across protocols. Each method trains only on tasks with an annotated source already in its ordinary candidate pool (broad for SCAR-Pair, strict request-only for Query-Pair); all fold-test tasks remain. $\Delta$nDCG is SCAR minus Query with shared-source-component bootstrap intervals and Holm-adjusted component sign tests. Candidate access remains an intentional method difference.}", r"\label{tab:revision_no_insertion}", r"\centering\small", r"\setlength{\tabcolsep}{4pt}", r"\begin{tabular}{llrrrr}", r"\toprule", r"Protocol & Method & Recall@5 & nDCG@5 & $\Delta$nDCG [95\% CI] & $p_H$ \\", r"\midrule"]
    names = (("Stratified", "stratified"), ("Unseen tool", "unseen_tool"),
             ("Shared source", "shared_source"), ("Leave source out", "leave_source_out"))
    for display, key in names:
        x, q, s = a[(key, "No-insertion-refit")], a[(key, "Query-Pair-no-insertion")], stats[(key, "ndcg")]
        lines.append(f"{display} & SCAR-Pair & {x['recall']:.3f} & {x['ndcg']:.3f} & {fmt_delta(s['difference'])} {fmt_ci(s['ci95'])} & {fmt_p(s['component_p_holm'])} " + r"\\")
        lines.append(f" & Query-Pair & {q['recall']:.3f} & {q['ndcg']:.3f} & --- & --- " + r"\\")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    (TABLES / "revision_no_insertion.tex").write_text("\n".join(lines) + "\n")


def make_reader():
    a = {r["condition"]: r for r in load("revision_reader_audit_report.json")["aggregates"]}
    lines = [r"\begin{table}[tbp]", r"\caption{Frozen-output selected-tool-name-lock diagnostic on 385 gold-schema-consistent tasks. The lock replaces only the parsed tool name after generation; argument values remain unchanged. Values are proportions except wrong-name counts. It is not constrained decoding and cannot establish a new reader's performance.}", r"\label{tab:revision_reader_audit}", r"\centering\small", r"\setlength{\tabcolsep}{4pt}", r"\begin{tabular}{lrrrrr}", r"\toprule", r"Context & Wrong name & Schema & Locked schema & Full-call & Locked full-call \\", r"\midrule"]
    for display, key in (("No memory", "No-memory"), ("Query-Fuse", "Query-Fuse-strict"),
                         ("SCAR-Pair", "SCAR-Pair"), ("Oracle-Gold", "Oracle-Gold")):
        r = a[key]
        lines.append(f"{display} & {r['wrong_tool_name']} & {r['original_schema_valid']:.3f} & {r['locked_schema_valid']:.3f} & {r['original_full_call_em']:.3f} & {r['locked_full_call_em']:.3f} " + r"\\")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    (TABLES / "revision_reader_audit.tex").write_text("\n".join(lines) + "\n")


def make_schema_components():
    report = load("revision_schema_components_report.json")
    aggregates = {r["method"]: r for r in report["aggregates"]}
    ndcg = {r["right"]: r for r in report["contrasts"] if r["metric"] == "ndcg"}
    rows = [
        ("Complete SCAR-Pair", "SCAR-Pair-component-refit"),
        ("Remove tool-level light", "No-tool-light"),
        ("Remove field lexical", "No-field-lexical"),
        ("Remove field dense", "No-field-dense"),
        ("Remove all field", "No-field-all"),
        ("Remove schema CE", "No-schema-CE"),
        ("Request-only scoring, broad pool", "Request-only-broad"),
    ]
    lines = [r"\begin{table}[tbp]",
             r"\caption{Matched leave-one-schema-component-out refits on the stratified folds ($n=391$). Every row uses the same schema-aware broad candidate pool, fold assignments, pairwise objective, and remaining coordinates. $\Delta$nDCG is the complete refit minus the ablation. Intervals use shared-source-component bootstrap resampling; $p_H$ is Holm-adjusted over Recall, Complete, and nDCG within each ablation. These post hoc group ablations quantify detectable dependence on information groups; they do not identify an individual parameter field as causally important.}",
             r"\label{tab:revision_schema_components}", r"\centering\scriptsize",
             r"\setlength{\tabcolsep}{3pt}", r"\begin{tabular}{lrrrrr}", r"\toprule",
             r"Variant & Recall@5 & nDCG@5 & $\Delta$nDCG & 95\% CI & $p_H$ \\",
             r"\midrule"]
    for label, key in rows:
        a = aggregates[key]
        if key == "SCAR-Pair-component-refit":
            tail = "--- & --- & ---"
        else:
            s = ndcg[key]
            tail = f"{fmt_delta(s['difference'])} & {fmt_ci(s['ci95'])} & {fmt_p(s['component_p_holm'])}"
        lines.append(f"{label} & {a['recall']:.3f} & {a['ndcg']:.3f} & {tail} " + r"\\")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    (TABLES / "revision_schema_components.tex").write_text("\n".join(lines) + "\n")


def make_grammar_reader():
    report = load("revision_grammar_reader_report.json")
    aggregates = {r["condition"]: r for r in report["aggregates"]}
    lines = [
        r"\begin{table}[tbp]",
        r"\caption{Token-level JSON-Schema-constrained reader and deterministic local dispatch on the 385 gold-schema-consistent tasks. The selected tool is fixed before generation, and LM Format Enforcer restricts the argument tokens to the translated schema. Local dispatch accepts a call only after the unchanged recursive validator succeeds and returns a deterministic receipt; it invokes no third-party API and produces no external side effect. Accepted exact requires the dispatched call to match the complete annotated call exactly.}",
        r"\label{tab:revision_grammar_reader}", r"\centering\small",
        r"\setlength{\tabcolsep}{3pt}", r"\begin{tabular}{lrrrrrr}", r"\toprule",
        r"Context & JSON & Schema & Local dispatch & Arg-EM & Call-EM & Accepted exact \\",
        r"\midrule",
    ]
    for display, key in (("Query-Fuse", "Query-Fuse-strict"), ("SCAR-Pair", "SCAR-Pair")):
        row = aggregates[key]
        lines.append(
            f"{display} & {row['json_validity']:.3f} & {row['schema_validity']:.3f} & "
            f"{row['execution_success']:.3f} & {row['memory_argument_em']:.3f} & "
            f"{row['memory_call_em']:.3f} & {row['execution_result_exact']:.3f} " + r"\\"
        )
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    (TABLES / "revision_grammar_reader.tex").write_text("\n".join(lines) + "\n")


if __name__ == "__main__":
    make_controls()
    make_no_insertion()
    make_sensitivity()
    make_reader()
    make_schema_components()
    make_grammar_reader()
