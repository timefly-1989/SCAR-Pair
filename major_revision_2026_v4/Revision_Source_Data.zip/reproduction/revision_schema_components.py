#!/usr/bin/env python3
"""Matched leave-one-schema-component-out refits on frozen stage-two features."""
from __future__ import annotations

import json
from collections import defaultdict

import joblib
import numpy as np

import publication_analysis as pub
import scar_pair_reproduce as base
import stage2_evaluate as ev
from pairwise_controls import fit


ALL = list(range(18))
VARIANTS = {
    "SCAR-Pair-component-refit": ("broad", "all", ALL, False),
    # Tool BM25/cosine and tool lexical/dense reciprocal ranks.
    "No-tool-light": ("broad", "all", [i for i in ALL if i not in (2, 3, 10, 11)], False),
    # Parameter-field BM25 max and mean.
    "No-field-lexical": ("broad", "all", [i for i in ALL if i not in (4, 5)], False),
    # Parameter-field dense max and mean.
    "No-field-dense": ("broad", "all", [i for i in ALL if i not in (6, 7)], False),
    # All four pooled parameter-field coordinates.
    "No-field-all": ("broad", "all", [i for i in ALL if i not in (4, 5, 6, 7)], False),
    # Schema CE score, reciprocal rank, and availability.
    "No-schema-CE": ("broad", "all", list(range(15)), False),
    # Request-only scoring coordinates on the same schema-aware broad pool.
    "Request-only-broad": ("broad", "all", [0, 1, 8, 9, 12, 13, 14], False),
}


def main() -> None:
    records = joblib.load(base.CACHE / "stage2_records.joblib")
    predictions, fits = [], []
    for fold, (train, test) in enumerate(ev.protocols(records)["stratified"]):
        for method, spec in VARIANTS.items():
            print(fold, method, flush=True)
            scale, model, diagnostic = fit(records, train, spec)
            fits.append({"fold": fold, "method": method, **diagnostic})
            pool, kind, columns, _ = spec
            for index in test:
                record = records[int(index)]
                ids = record[pool]
                x = ev.rows_for(record, ids, kind)[:, columns]
                scores = model.decision_function(x / scale)
                if not np.isfinite(scores).all():
                    raise ValueError(record["qa_id"])
                ranking = ids[np.lexsort((np.arange(len(ids)), -scores))]
                predictions.append({
                    "protocol": "stratified", "fold": fold, "method": method,
                    "qa_id": record["qa_id"],
                    "top10_document_indices": [int(v) for v in ranking[:10]],
                    **ev.task_metrics(ranking, record["gold"]),
                })

    output = base.OUTPUT / "revision_schema_components_predictions.jsonl"
    output.write_text("".join(json.dumps(r) + "\n" for r in predictions))
    aggregates = []
    lookup = defaultdict(dict)
    for row in predictions:
        lookup[row["method"]][row["qa_id"]] = row
    for method in VARIANTS:
        rows = list(lookup[method].values())
        aggregates.append({
            "method": method, "tasks": len(rows),
            **{metric: float(np.mean([r[metric] for r in rows]))
               for metric in ("hit", "recall", "complete", "mrr", "ndcg")},
        })

    components_array = ev.shared_source_groups(records)
    components = {r["qa_id"]: int(c) for r, c in zip(records, components_array)}
    contrasts = []
    for order, method in enumerate(VARIANTS):
        if method == "SCAR-Pair-component-refit":
            continue
        result = pub.paired(
            lookup["SCAR-Pair-component-refit"], lookup[method],
            ("recall", "complete", "ndcg"), components,
            base.SEED + 1800 + order,
        )
        contrasts.extend({
            "left": "SCAR-Pair-component-refit", "right": method, **row,
        } for row in result)

    report = {
        "status": "Post hoc matched component ablations; no model selection",
        "feature_order": [
            "B_q", "V_q", "B_t", "V_t", "field_B_max", "field_B_mean",
            "field_V_max", "field_V_mean", "RR_B_q", "RR_V_q",
            "RR_B_t", "RR_V_t", "CE_q", "RR_CE_q", "mask_q",
            "CE_schema", "RR_CE_schema", "mask_schema",
        ],
        "candidate_pool": "Same schema-aware broad pool for every variant",
        "inference": "10,000 shared-source-component bootstrap resamples; 50,000 joint component sign flips; Holm within each three-metric comparison",
        "aggregates": aggregates,
        "contrasts": contrasts,
        "fits": fits,
    }
    base.write_json(base.OUTPUT / "revision_schema_components_report.json", report)
    print(json.dumps({"aggregates": aggregates, "contrasts": contrasts}, indent=2))


if __name__ == "__main__":
    main()
