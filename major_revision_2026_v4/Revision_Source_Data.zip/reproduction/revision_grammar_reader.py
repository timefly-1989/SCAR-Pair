#!/usr/bin/env python3
"""JSON-Schema-constrained reader plus deterministic local execution harness.

The selected tool is fixed before generation. LM Format Enforcer restricts every
generated token to the selected tool's argument schema. A local dispatcher then
accepts only calls that pass the unchanged recursive validator and returns a
deterministic receipt. This tests schema-safe dispatch and result return without
claiming access to the unavailable third-party APIs behind benchmark schemas.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import time
from collections import Counter, defaultdict
from typing import Any

import numpy as np
import torch
from lmformatenforcer import JsonSchemaParser
from lmformatenforcer.integrations.transformers import (
    build_transformers_prefix_allowed_tokens_fn,
)
from tqdm import tqdm

import publication_analysis as pub
import reader_reproduce as reader
import revision_constrained_reader as constrained
import scar_pair_reproduce as base
import stage2_evaluate as ev


CONDITIONS = ("Query-Fuse-strict", "SCAR-Pair")
OUTPUT = base.OUTPUT / "revision_grammar_reader_predictions.jsonl"
REPORT = base.OUTPUT / "revision_grammar_reader_report.json"
MAX_NEW_TOKENS = 512


def standard_schema(node: dict[str, Any]) -> dict[str, Any]:
    """Translate released type aliases into JSON Schema Draft-compatible names."""
    allowed = {"description", "default", "enum", "pattern", "minimum", "maximum"}
    kind = {"dict": "object", "int": "integer", "float": "number"}.get(
        node.get("type"), node.get("type")
    )
    out: dict[str, Any] = {"type": kind}
    for key in allowed:
        if key in node:
            out[key] = node[key]
    if kind == "object":
        props = node.get("properties", {}) or {}
        out["properties"] = {key: standard_schema(value) for key, value in props.items()}
        out["required"] = list(node.get("required", []) or [])
        out["additionalProperties"] = False
    if kind == "array":
        out["items"] = standard_schema(node.get("items", {}) or {"type": "string"})
    return out


def argument_schema(task: dict[str, Any]) -> dict[str, Any]:
    parameters = task["target_tool_schema"].get("parameters", {}) or {}
    schema = standard_schema(parameters)
    if schema.get("type") != "object":
        raise ValueError(f"Non-object parameter schema: {task['qa_id']}")
    return schema


def execute_local(call: dict[str, Any], task: dict[str, Any]) -> dict[str, Any]:
    """Dispatch one validated call and return a deterministic execution receipt."""
    valid, error = reader.validate_call(call, task)
    if not valid:
        return {"status": "rejected", "error": error}
    return {
        "status": "ok",
        "selected_tool": task["target_tool_schema"]["name"],
        "arguments": call["arguments"],
        "receipt_sha256": hashlib.sha256(
            json.dumps(call, ensure_ascii=False, sort_keys=True,
                       separators=(",", ":")).encode("utf-8")
        ).hexdigest(),
    }


def existing_rows() -> dict[tuple[str, str], dict[str, Any]]:
    if not OUTPUT.exists():
        return {}
    rows = base.jsonl(OUTPUT)
    keys = [(r["condition"], r["qa_id"]) for r in rows]
    if len(keys) != len(set(keys)):
        raise ValueError("Duplicate grammar-reader rows")
    return dict(zip(keys, rows))


def run(limit: int | None, condition_filter: str | None = None) -> None:
    corpus = base.load_corpus()
    valid_ids, _ = reader.gold_consistency(corpus)
    tasks = [t for t in corpus.tasks if t["qa_id"] in valid_ids]
    rankings = reader.prediction_rankings()
    tokenizer, model = reader.load_model()
    done = existing_rows()
    selected = CONDITIONS if condition_filter is None else (condition_filter,)
    jobs = [(condition, task) for condition in selected for task in tasks
            if (condition, task["qa_id"]) not in done]
    if limit is not None:
        jobs = jobs[:limit]
    with OUTPUT.open("a", encoding="utf-8") as handle:
        for condition, task in tqdm(jobs, desc="grammar-reader"):
            docs = reader.condition_ids(task, condition, rankings, corpus)
            _, prompt_ids, memory_budget = constrained.build_constrained_prompt(
                task, docs, corpus, tokenizer
            )
            parser = JsonSchemaParser(argument_schema(task))
            prefix = build_transformers_prefix_allowed_tokens_fn(tokenizer, parser)
            input_ids = torch.tensor([prompt_ids], dtype=torch.long, device="mps")
            attention_mask = torch.ones_like(input_ids)
            started = time.perf_counter()
            with torch.inference_mode():
                generated = model.generate(
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    do_sample=False,
                    repetition_penalty=1.0,
                    max_new_tokens=MAX_NEW_TOKENS,
                    use_cache=True,
                    prefix_allowed_tokens_fn=prefix,
                    pad_token_id=tokenizer.eos_token_id,
                )
            elapsed = time.perf_counter() - started
            new_ids = generated[0, input_ids.shape[1]:].detach().cpu().tolist()
            raw_arguments = tokenizer.decode(new_ids, skip_special_tokens=True).strip()
            try:
                arguments = json.loads(raw_arguments)
                call = {"name": task["target_tool_schema"]["name"],
                        "arguments": arguments}
                raw_call = json.dumps(call, ensure_ascii=False, separators=(",", ":"))
            except Exception:
                call, raw_call = {}, raw_arguments
            scored = reader.score_output(raw_call, task)
            result = execute_local(call, task)
            row = {
                "model": "Qwen/Qwen2.5-1.5B-Instruct",
                "revision": reader.QWEN_REVISION,
                "constraint": "LM Format Enforcer 0.11.3 JsonSchemaParser",
                "condition": condition,
                "qa_id": task["qa_id"],
                "document_indices": docs,
                "document_ids": [corpus.documents[i]["id"] for i in docs],
                "prompt_sha256": hashlib.sha256(
                    np.asarray(prompt_ids, dtype=np.int32).tobytes()).hexdigest(),
                "argument_schema_sha256": hashlib.sha256(
                    json.dumps(argument_schema(task), sort_keys=True).encode()).hexdigest(),
                "input_tokens": len(prompt_ids),
                "output_tokens": len(new_ids),
                "memory_token_budget": memory_budget,
                "generation_seconds": elapsed,
                "raw_argument_output": raw_arguments,
                "raw_output": raw_call,
                "execution_status": result["status"],
                "execution_result": result,
                "execution_result_exact": bool(result["status"] == "ok" and scored["full_call_em"]),
                **scored,
            }
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
            handle.flush()
    if len(existing_rows()) == len(CONDITIONS) * len(tasks):
        summarize()


def summarize() -> None:
    corpus = base.load_corpus()
    valid_ids, failures = reader.gold_consistency(corpus)
    rows = [r for r in base.jsonl(OUTPUT) if r["qa_id"] in valid_ids]
    expected = {(c, q) for c in CONDITIONS for q in valid_ids}
    if {(r["condition"], r["qa_id"]) for r in rows} != expected or len(rows) != len(expected):
        raise ValueError(f"Incomplete grammar-reader trace: {len(rows)}/{len(expected)}")
    aggregates = []
    lookup = defaultdict(dict)
    for row in rows:
        lookup[row["condition"]][row["qa_id"]] = row
    for condition in CONDITIONS:
        subset = list(lookup[condition].values())
        aggregates.append({
            "condition": condition, "tasks": len(subset),
            "json_validity": float(np.mean([r["json_valid"] for r in subset])),
            "schema_validity": float(np.mean([r["schema_valid"] for r in subset])),
            "execution_success": float(np.mean([r["execution_status"] == "ok" for r in subset])),
            "memory_argument_em": float(np.mean([r["memory_argument_em"] for r in subset])),
            "memory_call_em": float(np.mean([r["memory_call_em"] for r in subset])),
            "full_call_em": float(np.mean([r["full_call_em"] for r in subset])),
            "execution_result_exact": float(np.mean([r["execution_result_exact"] for r in subset])),
            "max_output_hits": int(sum(r["output_tokens"] >= MAX_NEW_TOKENS for r in subset)),
        })
    records = __import__("joblib").load(base.CACHE / "stage2_records.joblib")
    labels = ev.shared_source_groups(records)
    components = {r["qa_id"]: int(c) for r, c in zip(records, labels)}
    paired = pub.paired(
        lookup["SCAR-Pair"], lookup["Query-Fuse-strict"],
        ("memory_argument_em", "memory_call_em", "full_call_em"), components,
        base.SEED + 1900,
    )
    report = {
        "model": "Qwen/Qwen2.5-1.5B-Instruct",
        "constraint": "Selected tool fixed before generation; LM Format Enforcer 0.11.3 enforces the translated argument JSON Schema token by token",
        "execution": "Local deterministic schema-gated dispatcher returns a receipt; no third-party API or external side effect",
        "conditions": list(CONDITIONS),
        "gold_schema_consistent": len(valid_ids),
        "gold_schema_inconsistent": failures,
        "completed_by_condition": dict(Counter(r["condition"] for r in rows)),
        "generation_seconds": float(sum(r["generation_seconds"] for r in rows)),
        "aggregates": aggregates,
        "paired_scar_minus_query": paired,
        "prediction_file_sha256": base.sha256(OUTPUT),
    }
    base.write_json(REPORT, report)
    print(json.dumps(report, ensure_ascii=False, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("run", "summarize"))
    parser.add_argument("--limit", type=int)
    parser.add_argument("--condition", choices=CONDITIONS)
    args = parser.parse_args()
    if args.command == "run":
        run(args.limit, args.condition)
    else:
        summarize()


if __name__ == "__main__":
    main()
