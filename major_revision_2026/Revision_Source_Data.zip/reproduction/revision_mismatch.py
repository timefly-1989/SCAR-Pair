#!/usr/bin/env python3
"""One fixed mismatched-schema CE placebo with the request and pool held fixed."""
from __future__ import annotations

import json
import time

import joblib
import numpy as np

import revision_controls as controls
import scar_pair_reproduce as base
import stage2_evaluate as ev


def mismatched_left(current, donor):
    current_request = base.query_text(current)
    donor_schema = donor["target_tool_schema"]
    out = (f"Request: {current_request}\n"
           f"Tool name: {donor_schema.get('name', '')}\n"
           f"Tool description: {donor_schema.get('description', '')}")
    for name, spec in base.properties(donor):
        out += f"\nParameter name: {name}\nParameter description: {spec.get('description', '')}"
    return out


def main():
    records = joblib.load(base.CACHE / "stage2_records.joblib")
    rng = np.random.default_rng(base.SEED + 1200)
    names = [r["task"]["target_tool_schema"]["name"] for r in records]
    for _ in range(10000):
        donor = rng.permutation(len(records))
        if all(names[i] != names[int(donor[i])] for i in range(len(records))):
            break
    else:
        raise RuntimeError("Could not build different-tool permutation")
    corpus = base.load_corpus()
    documents = [d["text"] for d in corpus.documents]
    model = ev.load_ce()
    started = time.perf_counter()
    pair_count = 0
    raw_scores = []
    for i, record in enumerate(records):
        left = mismatched_left(record["task"], records[int(donor[i])]["task"])
        pool = record["narrow"]
        pairs = [(left, documents[int(index)]) for index in pool]
        score = np.asarray(model.predict(pairs, batch_size=128,
                                         show_progress_bar=False, convert_to_numpy=True),
                           dtype=np.float32).reshape(-1)
        if not np.isfinite(score).all():
            raise ValueError(record["qa_id"])
        second = ev.extend_view(record["train_ids"], pool, score)
        record["ce_narrow"] = np.column_stack((record["ce_narrow"][:, :3], second)).astype(np.float32)
        raw_scores.append({"qa_id": record["qa_id"], "donor_qa_id": records[int(donor[i])]["qa_id"],
                           "narrow_document_indices": [int(x) for x in pool],
                           "mismatched_schema_ce_logits": [float(x) for x in score]})
        pair_count += len(pairs)
        if (i + 1) % 25 == 0:
            print(f"scored {i+1}/{len(records)}", flush=True)
    scoring_seconds = time.perf_counter() - started
    predictions, fits = [], []
    for fold, (train, test) in enumerate(ev.protocols(records)["stratified"]):
        scale, clf, diagnostic = controls.fit(records, train, "SCAR-Pair-refit")
        fits.append({"fold": fold, **diagnostic})
        for index in test:
            r = records[int(index)]
            ids = r["broad"]
            scores = clf.decision_function(controls.features(r, ids, "SCAR-Pair-refit") / scale)
            order = ids[np.lexsort((np.arange(len(ids)), -scores))]
            predictions.append({"protocol": "stratified", "fold": fold,
                                "method": "Mismatched-schema-CE", "qa_id": r["qa_id"],
                                "top10_document_indices": [int(v) for v in order[:10]],
                                **ev.task_metrics(order, r["gold"])})
    out = base.OUTPUT
    (out / "revision_mismatch_ce_scores.jsonl").write_text(
        "".join(json.dumps(r) + "\n" for r in raw_scores), encoding="utf-8")
    (out / "revision_mismatch_predictions.jsonl").write_text(
        "".join(json.dumps(r) + "\n" for r in predictions), encoding="utf-8")
    report = {"control": "One fixed different-tool schema permutation (seed 20261930); current request and broad/narrow candidate pools retained; only schema CE triplet replaced",
              "donors": [{"qa_id": r["qa_id"], "donor_qa_id": records[int(donor[i])]["qa_id"]}
                         for i, r in enumerate(records)],
              "ce_pairs": pair_count, "scoring_seconds": scoring_seconds,
              "fits": fits,
              "aggregates": {m: float(np.mean([r[m] for r in predictions]))
                             for m in ("hit", "recall", "complete", "mrr", "ndcg")}}
    (out / "revision_mismatch_report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"ce_pairs": pair_count, "scoring_seconds": scoring_seconds,
                      "aggregates": report["aggregates"]}, indent=2))


if __name__ == "__main__":
    main()
